# Phase 1 QA — owner review build

## Verified results

- The reconstructed five-part ZIP matches the owner's exact SHA-256. Duplicate Part 1 was excluded. All manifest files and nested source/research ZIPs were verified and opened.
- **20 content pages × 4 widths = 80 completed browser/page checks**, with full-page PNG screenshots at **375, 390, 768 and 1440px**. This includes the complete homepage through footer, all three articles, research, physicians, patient/physician inquiry previews, FAQ, both complete legal pages, contact, ingredient pages, the source bibliography audit and the retained legacy order page.
- Every tested page returned HTTP 200; no broken images, page JavaScript errors or horizontal document overflow were found. Desktop/mobile semantic text, image sources/alt values and anchor targets match at all widths.
- All **18 functional checks passed**, including the visible mobile treatment CTA, two-link menu, Escape/focus restoration, exact three science cards, eight homepage FAQ questions, dedicated 13-slot FAQ controls, DOI search, research filters/reset/empty state, four disabled physician fields, honest callback/calendar status, complete legal section counts and no-JavaScript navigation/FAQ availability.
- axe-core WCAG 2 A/AA and WCAG 2.1 AA tags found **zero automated violations on all 20 content pages**. Incomplete checks are retained for manual follow-up; this is not a full accessibility certification.
- Existing compared page body content has **zero unapproved wording/order differences**, after allowing only the explicitly authorized science-card headings, source restoration, legal replacement and inquiry/privacy/calendar additions. All three article bodies/citations remain identical; all 29 current research records are byte-for-byte unchanged. The baseline is identified in CONTENT_PRESERVATION.md, not presented as proof that old pending copy had been approved.
- Privacy has **17 numbered sections, 78 paragraphs and 25 list items**. Terms has **24 numbered sections, 98 paragraphs and 14 list items**. Entire rendered text matches the supplied legal source after authorized placeholder substitutions; no `[INSERT ...]` fields remain.
- Non-www `https://biohairxrx.com` canonicals are configured. The retained `/order.html` information page canonicalizes to `/order-information/`; no premature inquiry redirect was activated. Indexing restrictions remain in place. No analytics, advertising pixels, Search Console activation or sitemap submission occurred.
- Local links and anchors pass. The prior 31 external URLs were newly attempted; all 34 total external checks remain unresolved due to enforced proxy policy. They are not marked verified or treated as broken because of policy denial.

## Lighthouse measurements

| Homepage profile | Performance | Accessibility | Best practices | SEO | LCP | CLS |
|---|---:|---:|---:|---:|---:|---:|
| mobile | 98 | 100 | 100 | 69 | 2.40s | 0.000 |
| desktop | 100 | 100 | 100 | 69 | 0.44s | 0.000 |

The homepage met the stated laboratory performance goal of 90+ and LCP under 2.5s in these runs. Lighthouse was not run for all 20 pages. SEO's 69 score includes intentional staging noindex/robots restrictions; those restrictions were not removed to improve a score. These are local simulated laboratory results, not production field Core Web Vitals or a guarantee of mobile-network performance. Raw JSON and HTML reports are included.

## Fixes made during QA

The first no-JavaScript mobile menu check failed; an explicit fallback rule fixed it. The first mobile LCP measurement was 2.6s; product srcset sizing/loading priority reduced unnecessary image transfer while retaining authentic printed artwork. A favicon derivative removed a browser 404. The final 80-check run and both Lighthouse runs reflect those corrections.

## Held / untested work

Exact expanded homepage ingredient copy, the conflicting eight-question visual, missing dedicated FAQ copy and definitive standalone inquiry designs are not certified complete; the affected source-dependent parts were held rather than invented. PENDING_ITEMS.md records the differences and required owner input.

Forms, callback delivery and calendar booking are not operational or end-to-end tested. Profile/publisher live links remain unverified. Safari, Firefox, physical devices, screen readers, cPanel/Apache routing, field performance, legal correctness and clinical peer review were not tested. No production system or GitHub branch was changed.

## Evidence

RESPONSIVE_QA_CHECKLIST.csv; browser-results.json; accessibility-results.json; CONTENT_DIFF.csv; ARTICLE_PRESERVATION.csv; LEGAL_VERBATIM_CHECK.csv; CITATION_CONTEXT_REGISTER.csv; LINK_REGISTER.csv; EXTERNAL_LINK_CHECKS.csv; SEO_PAGE_REGISTER.csv; MODIFIED_FILES.csv; AUTHENTIC_PRODUCT_VERIFICATION.csv; Lighthouse HTML/JSON; and the 80 actual screenshot files.
