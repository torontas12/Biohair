# BIOHAIR X — TERMS OF SERVICE

**Effective Date: October 31, 2026**

**Website:** [https://BioHairXRx.com](https://BioHairXRx.com)\
**Contact:** [info@BioHairXRx.com](mailto:info@BioHairXRx.com)

## 1. Acceptance of Terms

Welcome to BioHair X.

These Terms of Service (“Terms”) govern access to and use of BioHairXRx.com (the “Website”), including its informational materials, physician inquiry forms, consumer consultation requests, and related website features.

The Website is operated on behalf of the BioHair X product brand by Core Research Laboratories Inc. (“Company,” “we,” “our,” or “us”).

By accessing or using the Website, you agree to comply with these Terms and applicable law. If you do not agree, please discontinue use.

These Terms apply to the Website and its informational and inquiry services. They do not replace any separate agreement between a patient and a healthcare provider, or between a healthcare professional and a product supplier.

## 2. Nature and Purpose of the Website

BioHair X is a prescription-only topical hair-treatment product.

The Website is intended to provide general information about BioHair X, relevant scientific research, physician-directed treatment considerations, and opportunities to request further information.

The Website also permits healthcare professionals to submit inquiries concerning BioHair X.

**The Website does not currently operate as an online pharmacy, sell prescription medication directly to consumers, process payments, or provide an integrated telemedicine consultation service.**

Submitting an inquiry does not constitute a medication order or create an obligation to purchase any product.

## 3. Prescription Medication and Professional Medical Evaluation

BioHair X is intended to be used only under the direction of an appropriately licensed healthcare professional and dispensed in accordance with applicable law.

No individual should obtain or use prescription medication without a valid prescription when one is legally required.

A healthcare professional must independently determine whether any particular treatment is medically appropriate based on the patient's circumstances.

Information presented on the Website does not constitute a prescription, diagnosis, individualized treatment recommendation, or guarantee of medical eligibility.

Availability of BioHair X may vary based on applicable law, product formulation, professional judgment, and lawful dispensing arrangements.

Nothing on the Website authorizes the manufacture, distribution, prescribing, dispensing, or administration of a medication contrary to applicable federal or state law.

## 4. No Medical Advice

Website content is provided for general educational and informational purposes.

Although content may discuss clinical research, ingredients, treatment mechanisms, and hair-loss conditions, it is not intended to substitute for a consultation with a licensed healthcare professional.

Do not disregard professional medical advice, discontinue prescribed treatment, or delay seeking medical attention because of information presented on this Website.

Individual treatment responses vary. No particular clinical outcome is guaranteed.

**For a medical emergency, call 911 or seek immediate emergency medical assistance. Do not use Website inquiry forms for emergencies.**

## 5. Independent Physicians and Clinics

BioHair X may be discussed or prescribed by appropriately licensed healthcare professionals, subject to applicable law.

Physicians and clinics are responsible for their own clinical evaluations, prescribing decisions, patient communications, professional obligations, and medical services.

Unless expressly stated otherwise in a separate written agreement, the Website does not employ or control the professional medical judgment of participating healthcare providers.

The Company does not direct a physician to prescribe BioHair X to any particular patient.

A physician's decision to prescribe, decline to prescribe, modify, or discontinue a treatment remains an independent clinical decision.

No physician-patient relationship is established solely by visiting the Website or submitting an inquiry.

## 6. Consultation Requests

Consumers may submit contact information to request assistance arranging a physician consultation or obtaining further information.

At present, these requests are directed to Elite Hair Institutes for follow-up.

A request does not guarantee:

- An appointment;
- Acceptance as a patient;
- A particular diagnosis;
- Eligibility for BioHair X;
- Issuance of a prescription;
- Insurance coverage;
- Any particular treatment outcome.

Healthcare services, if provided, are subject to the independent provider's policies, professional judgment, and applicable legal requirements.

If the Website later offers referrals to additional clinics, those arrangements may be governed by supplemental disclosures.

## 7. Physician and Professional Inquiries

Licensed healthcare professionals may use the Website to request product information, discuss potential professional relationships, or inquire about lawful availability.

Professional inquiries do not create a distributor agreement, purchasing relationship, or authorization to obtain prescription medications.

Any professional purchase, supply, dispensing, or distribution arrangement must comply with applicable federal and state laws, licensing requirements, and separate written agreements.

We may request verification of professional credentials or other information before responding to certain inquiries.

## 8. No Online Payments or Subscriptions

The Website does not currently accept consumer payments, maintain paid consumer subscriptions, or process online prescription orders.

Prices, if mentioned, are informational and may differ from prices charged by independent clinics or other authorized providers.

Consultation fees, treatment costs, billing arrangements, refunds, and payment disputes involving independent healthcare providers are governed by the terms disclosed by those providers.

The Company does not assume responsibility for independent providers' billing practices merely because a consumer initially contacted them through the Website.

## 9. Product Information and Regulatory Status

BioHair X product information may describe ingredients, formulations, research findings, or potential applications.

Published studies concerning individual ingredients do not necessarily establish the safety or effectiveness of the finished BioHair X formulation.

Where applicable, compounded prescription drug products are not FDA-approved, and the FDA has not reviewed them for safety, effectiveness, or manufacturing quality before marketing in the manner applicable to FDA-approved drugs.

Nothing on this Website should be interpreted as representing that an investigational or compounded formulation has received FDA approval unless that approval has actually been obtained and expressly identified.

Product descriptions and research summaries are not guarantees of effectiveness or safety.

Healthcare professionals and patients should review the applicable prescription information, formulation details, warnings, and professional guidance before making treatment decisions.

## 10. Scientific and Educational Content

The Website may publish scientific articles, research summaries, clinical discussions, and references to third-party publications.

Such materials are provided for educational purposes.

Research findings may involve different patient populations, formulations, doses, study methods, and limitations.

We seek to present information responsibly but do not guarantee that all scientific content will remain complete, current, or applicable to every individual.

The inclusion of a scientific publication does not mean its authors endorse BioHair X.

## 11. User Responsibilities

When using the Website, you agree to:

1. Provide accurate contact information when submitting inquiries.
2. Use the Website only for lawful purposes.
3. Refrain from impersonating another individual or healthcare professional.
4. Avoid transmitting malicious software or attempting unauthorized access.
5. Refrain from interfering with Website security or operation.
6. Respect the intellectual property rights of the Company and others.
7. Avoid submitting confidential patient records or sensitive medical information through general inquiry forms.

We may restrict access to Website features when reasonably necessary to address misuse, security threats, or legal obligations.

## 12. Intellectual Property

Unless otherwise stated, the Website's original text, designs, graphics, logos, product images, layout, and other proprietary content are owned by or licensed to the Company or its licensors.

BioHair X and associated branding may be protected by trademark and other intellectual property laws.

You receive a limited, nonexclusive, revocable permission to access and use Website materials for lawful personal informational purposes or legitimate professional evaluation.

You may not reproduce, commercially exploit, distribute, modify, or republish substantial Website materials without prior written authorization, except as permitted by applicable law.

Third-party research articles, trademarks, and other materials remain the property of their respective owners.

## 13. Third-Party Links and Resources

The Website may provide links to scientific journals, independent healthcare professionals, professional organizations, and other third-party websites.

We do not control all third-party content or practices.

Links are provided for convenience and informational purposes and do not automatically constitute endorsement, affiliation, or a guarantee of third-party services.

Your use of third-party websites is subject to their respective policies and terms.

## 14. Privacy

Our collection and use of personal information are described in the BioHair X Privacy Policy, available through the Website.

Please review that Policy before submitting an inquiry.

By providing contact information, you authorize us to use it to respond to your specific request, subject to applicable privacy and communications laws.

Submitting a telephone number does not, by itself, constitute consent to receive automated promotional calls or text messages.

## 15. Electronic Communications

When you contact us electronically, you agree that we may respond electronically regarding your inquiry, subject to applicable law.

Email and ordinary electronic communications may not provide the same confidentiality protections as a secure patient portal.

Do not use general Website forms or ordinary email to transmit sensitive medical records unless appropriate secure arrangements have been established.

Any future promotional text-message or automated calling program will be subject to separate legally required disclosures and consent.

## 16. Availability and Changes to the Website

We may modify, suspend, or discontinue Website content or features when reasonably necessary for operational, technical, security, legal, or business reasons.

We do not guarantee uninterrupted Website availability.

We may correct errors, update scientific information, or remove outdated content.

Material changes to these Terms will be reflected in a revised effective date and accompanied by additional notice when legally required.

## 17. Disclaimer of Warranties

TO THE MAXIMUM EXTENT PERMITTED BY APPLICABLE LAW, THE WEBSITE AND ITS INFORMATIONAL CONTENT ARE PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS.

WE DO NOT WARRANT THAT THE WEBSITE WILL BE UNINTERRUPTED, ERROR-FREE, OR FREE FROM SECURITY RISKS, OR THAT ALL INFORMATION WILL BE COMPLETE OR CURRENT AT ALL TIMES.

WE MAKE NO GUARANTEE THAT USE OF THE WEBSITE WILL RESULT IN AN APPOINTMENT, PRESCRIPTION, MEDICAL BENEFIT, OR PARTICULAR CLINICAL OUTCOME.

THIS SECTION DOES NOT DISCLAIM WARRANTIES OR RESPONSIBILITIES THAT CANNOT LAWFULLY BE EXCLUDED.

## 18. Limitation of Liability

TO THE FULLEST EXTENT PERMITTED BY APPLICABLE LAW, THE COMPANY AND ITS RESPECTIVE OFFICERS, EMPLOYEES, AND AUTHORIZED REPRESENTATIVES SHALL NOT BE LIABLE FOR INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, OR PUNITIVE DAMAGES ARISING SOLELY FROM USE OF OR INABILITY TO USE THE WEBSITE, EXCEPT WHERE SUCH EXCLUSION IS PROHIBITED BY LAW.

THIS LIMITATION DOES NOT EXCLUDE LIABILITY FOR FRAUD, WILLFUL MISCONDUCT, PERSONAL INJURY, VIOLATIONS OF NONWAIVABLE CONSUMER RIGHTS, OR OTHER MATTERS FOR WHICH LIABILITY CANNOT LAWFULLY BE LIMITED.

Nothing in these Terms limits a healthcare professional's independent legal responsibilities or removes statutory rights belonging to patients or consumers.

## 19. Indemnification

To the extent permitted by applicable law, you agree to be responsible for losses and reasonable costs directly resulting from your unlawful misuse of the Website, intentional interference with its security, or infringement of third-party rights.

This provision does not require you to indemnify the Company for its own negligence, unlawful conduct, or other liabilities that cannot legally be shifted to consumers.

## 20. Governing Law and Disputes

These Terms are governed by the laws of the State of California, without regard to conflict-of-law principles, except where mandatory consumer protection laws require otherwise.

Before initiating formal proceedings concerning a Website-related dispute, you are encouraged to contact [info@BioHairXRx.com](mailto:info@BioHairXRx.com) so that we may attempt to resolve the matter informally.

Subject to applicable law, disputes not resolved informally may be brought before courts having proper jurisdiction in California.

These Terms do not impose mandatory arbitration or a class-action waiver.

Nothing in these Terms restricts rights or remedies that cannot lawfully be waived.

## 21. Severability

If any provision of these Terms is determined to be invalid or unenforceable, that provision shall be limited or severed to the extent necessary, and the remaining provisions shall continue in effect to the extent permitted by law.

## 22. No Waiver

A failure to enforce a provision of these Terms does not constitute a waiver of the right to enforce that provision in the future.

## 23. Entire Agreement

These Terms, together with the Privacy Policy and any applicable supplemental Website notices, constitute the agreement governing use of the Website.

They do not supersede independent medical-service agreements, physician-patient relationships, pharmacy terms, or separately executed professional supply contracts.

## 24. Contact Information

Questions concerning these Terms may be directed to:

**BioHair X — Legal and Website Inquiries**\
Email: [info@BioHairXRx.com](mailto:info@BioHairXRx.com)\
Website: [https://BioHairXRx.com](https://BioHairXRx.com)

Legal website operator: Core Research Laboratories Inc.\
Mailing address: 20162 SW Birch Street, Newport Beach, CA 92660

**End of Terms of Service**