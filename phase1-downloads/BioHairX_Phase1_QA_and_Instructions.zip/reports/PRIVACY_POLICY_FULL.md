# BIOHAIR X — PRIVACY POLICY

**Effective Date: October 31, 2026**

**Website:** [https://BioHairXRx.com](https://BioHairXRx.com)\
**Privacy Contact:** [info@BioHairXRx.com](mailto:info@BioHairXRx.com)

## 1. Introduction

BioHair X (“BioHair X,” “we,” “us,” or “our”) is a prescription hair-treatment product brand associated with Elite Hair Institutes. This Privacy Policy describes how personal information is collected, used, disclosed, protected, and retained in connection with the website at BioHairXRx.com (the “Website”) and related inquiries.

The Website provides educational information about BioHair X and allows consumers and healthcare professionals to request additional information or assistance connecting with an appropriate healthcare professional.

The Website does not currently sell prescription medications directly to consumers, process payments, or provide medical consultations through an integrated online platform.

**Website operator:** Core Research Laboratories Inc.

Please read this Privacy Policy carefully. By using the Website, you acknowledge that you have been provided access to this Policy. Where required by law, we will request separate consent for particular information-processing activities.

## 2. Information We Collect

### Information You Provide

When you complete an inquiry or consultation-request form, we may collect:

- Your name;
- Email address;
- Telephone number;
- The type of inquiry you submit, such as a consumer consultation request or physician inquiry;
- Information you voluntarily include in communications with us.

Healthcare professionals may also provide practice or clinic information, professional contact details, and other business information.

We do not currently request payment card details, insurance information, Social Security numbers, or complete medical histories through the Website.

**Please do not submit diagnoses, medical records, photographs, prescription details, or other sensitive health information through a general inquiry form unless a specifically designated secure process is provided.**

If you voluntarily provide health-related information, we will handle it with appropriate confidentiality and in accordance with applicable law.

### Information Collected Automatically

Our website-hosting and security providers may automatically process technical information necessary to deliver and protect the Website, such as:

- Internet Protocol (IP) address;
- Browser and device characteristics;
- Date and time of requests;
- Requested pages and technical error information;
- Security and server-log information.

We do not currently use Google Analytics, Google Ads remarketing, Meta Pixel, or comparable advertising-tracking tools, based on our present website configuration.

This Policy will be updated before we introduce additional analytics, advertising, or tracking technologies that materially change our information practices.

## 3. How We Use Personal Information

We use personal information for legitimate operational purposes, including:

1. Responding to consumer and physician inquiries.
2. Arranging or facilitating requested contact with Elite Hair Institutes.
3. Providing information about BioHair X and the process for obtaining a physician consultation.
4. Communicating with healthcare professionals regarding potential professional relationships.
5. Maintaining and improving the functionality and security of the Website.
6. Preventing fraud, unauthorized activity, and misuse.
7. Meeting applicable legal, regulatory, and recordkeeping obligations.
8. Addressing privacy requests, complaints, and disputes.

We will not treat a consultation request as permission to send unrelated promotional text messages or automated marketing calls. Where marketing consent is required, we will request it separately.

## 4. Consumer Consultation Requests

When you submit a request for a physician consultation, your contact information is currently directed to **Elite Hair Institutes**, which may contact you regarding your inquiry and available next steps.

Submitting an inquiry does not establish a physician-patient relationship, constitute a medical evaluation, guarantee an appointment, or guarantee that BioHair X will be prescribed.

Any diagnosis, treatment recommendation, or prescription decision must be made by an appropriately licensed healthcare professional exercising independent clinical judgment.

If we later introduce geographic referral routing or share inquiries with additional participating clinics, we will provide appropriate notice and obtain consent when required before implementing that practice.

## 5. Disclosure of Personal Information

We may disclose information to the following categories of recipients where necessary and legally permitted:

**Elite Hair Institutes.** To respond to consultation requests and other inquiries submitted through the Website.

**Website and technology providers.** Hosting, email, form-processing, technical support, and cybersecurity vendors that support our operations.

**Professional advisers.** Attorneys, accountants, insurers, and other advisers when reasonably necessary for legitimate business purposes.

**Government and regulatory authorities.** When disclosure is required by applicable law, lawful process, or a valid governmental request.

**Business successors.** In connection with a lawful merger, acquisition, restructuring, or transfer of business assets, subject to applicable privacy obligations.

We do not currently disclose consumer inquiry information to an advertising network for cross-context behavioral advertising.

We do not currently sell personal information for monetary compensation.

We do not authorize service providers to use inquiry information for their independent advertising purposes merely because they provide technical services to the Website.

## 6. Health-Related Information and Medical Privacy

A request for information about a hair-loss treatment may reveal an individual's interest in healthcare services and should be treated as potentially sensitive.

The Website is primarily an informational and referral resource. It is not intended to function as a patient medical-record portal.

Information maintained by a physician, clinic, pharmacy, or other healthcare provider may be subject to separate privacy notices and additional legal requirements, including the Health Insurance Portability and Accountability Act (HIPAA), where applicable.

Not all information submitted to a health-related website is automatically protected by HIPAA. Other federal and state privacy laws may also apply.

We will not represent that all Website communications are HIPAA-protected or transmitted through a HIPAA-compliant patient portal unless those claims have been verified.

## 7. Cookies and Similar Technologies

The Website may use technologies necessary for ordinary website functionality, security, and performance.

At the effective date of this Policy, we do not knowingly deploy third-party advertising pixels or behavioral advertising analytics.

If we introduce Google Analytics, Google Ads, Meta Pixel, or similar technologies, we will first evaluate their privacy implications, update this Policy, and implement applicable notices, consent mechanisms, and consumer privacy choices.

We will take particular care not to disclose identifiable consultation-request information or sensitive health-related activity to advertising platforms in ways prohibited by applicable law.

## 8. Data Security

We use, or require our service providers to use, safeguards reasonably appropriate to the nature and sensitivity of the information processed.

Such safeguards may include access restrictions, secure communications, vendor controls, monitoring, and procedures for responding to suspected security incidents.

No website, electronic transmission, or information-storage system can be guaranteed completely secure.

If a security incident occurs, we will investigate and provide legally required notices to affected individuals and authorities within applicable deadlines.

If you believe information submitted through the Website has been compromised, contact [info@BioHairXRx.com](mailto:info@BioHairXRx.com).

## 9. Data Retention

We retain personal information only for as long as reasonably necessary to respond to inquiries, maintain relevant business records, fulfill the purposes described in this Policy, resolve disputes, and comply with applicable legal obligations.

Retention periods may vary depending on the nature of the inquiry, legal requirements, and whether a continuing professional or business relationship exists.

When information is no longer reasonably necessary, we will delete, deidentify, or otherwise securely dispose of it, subject to applicable recordkeeping obligations.

## 10. California Privacy Rights

California residents may have privacy rights under the California Consumer Privacy Act, as amended by the California Privacy Rights Act, and other applicable laws.

Depending on the law's applicability and available exceptions, these rights may include:

- Requesting information about personal information collected and disclosed;
- Requesting access to or copies of personal information;
- Requesting correction of inaccurate personal information;
- Requesting deletion of personal information;
- Opting out of certain sales or sharing of personal information;
- Limiting certain uses of sensitive personal information;
- Exercising applicable privacy rights without unlawful discrimination or retaliation.

Some rights are subject to verification, statutory exceptions, and other legal limitations.

**Submitting a privacy request:** Email [info@BioHairXRx.com](mailto:info@BioHairXRx.com) with the subject line “Privacy Request.”

Please describe the request and provide sufficient information for us to identify the relevant records. We may take reasonable steps to verify your identity before responding.

We will respond within timeframes required by applicable law.

We do not currently knowingly sell or share personal information for cross-context behavioral advertising. If that practice changes, we will implement applicable opt-out mechanisms before doing so.

Where legally required, we will recognize applicable browser-based opt-out preference signals.

## 11. Other State Privacy Rights

Residents of other states may have additional rights concerning access, correction, deletion, portability, and certain uses of personal information.

We will honor applicable rights in accordance with the laws governing the relevant request.

To exercise these rights, contact [info@BioHairXRx.com](mailto:info@BioHairXRx.com).

## 12. Marketing Communications

We may send communications necessary to respond to your inquiry or provide information you specifically requested.

We will not interpret the submission of a telephone number as blanket consent to receive automated marketing calls or promotional text messages.

If we later offer email newsletters, promotional messaging, or text-message programs, we will provide legally required disclosures, obtain any necessary consent, and provide appropriate opt-out methods.

## 13. Children's Privacy

The Website is intended primarily for adults and healthcare professionals.

We do not knowingly solicit personal information directly from children under 13.

Individuals under 18 should not submit consultation requests without appropriate parental or guardian involvement where required.

If we learn that personal information was collected from a child in violation of applicable law, we will take appropriate corrective action.

## 14. Third-Party Websites and Healthcare Providers

The Website may contain links to independent physicians, clinics, research publications, or other third-party resources.

Those parties may operate under their own privacy policies and legal obligations.

We encourage users to review the privacy practices of any third party before providing personal or medical information directly to that party.

## 15. International Visitors

The Website is principally intended for visitors in the United States.

If you access the Website from another country, your information may be processed in the United States, subject to applicable law.

We do not represent that all Website services or referenced treatments are available or legally authorized in every jurisdiction.

## 16. Changes to This Privacy Policy

We may update this Privacy Policy to reflect changes in our operations, technologies, legal obligations, or information practices.

The updated Policy will be posted on the Website with a revised effective date.

Where applicable law requires additional notice or consent for material changes, we will provide it.

## 17. Contact Information

For questions, privacy requests, or concerns regarding this Policy, contact:

**BioHair X — Privacy Inquiries**\
Email: [info@BioHairXRx.com](mailto:info@BioHairXRx.com)\
Website: [https://BioHairXRx.com](https://BioHairXRx.com)

Legal website operator: Core Research Laboratories Inc.\
Mailing address: 20162 SW Birch Street, Newport Beach, CA 92660

**End of Privacy Policy**