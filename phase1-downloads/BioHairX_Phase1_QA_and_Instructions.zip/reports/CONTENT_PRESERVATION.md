# Content preservation and authorized differences

## Baseline and provenance

The comparison baseline is the previously delivered website archive, SHA-256 `2ce48895a0e477d090c3f8f8eb064602535ccb2ed2c5d903004f3c40b446f40e`. It was extracted into a separate read-only comparison folder. The final supplied implementation archive contains older source and frozen supporting references; these were also extracted and inspected, not skipped. The prior delivered build is a concrete comparison baseline, not an assertion that every old pending item had received owner approval.

The reconstructed final handoff matches the owner's SHA-256 `90139be11ecf9438a47b656f6b0b0dfd29cf3929c967b9fbb4f46ae48f3ebc30`. The duplicate first part is byte-for-byte identical and was not appended twice. All three top-level nested ZIPs passed CRC tests, their manifest digests/sizes matched, and their nested source/research archives were opened and extracted.

## Exact checks

- `CONTENT_DIFF.csv` compares ordered semantic text elements in existing page main content: headings, paragraphs, list items, definition lists, FAQ summaries and labels. The only allowed homepage text differences are the owner-specified three card headings. There are zero other unapproved wording/order differences in the compared existing pages.
- Article body elements, citations and their order remain identical to the delivered baseline for all three articles. `ARTICLE_PRESERVATION.csv` records the result.
- All 29 current publication records, including limitations and verification labels, are byte-for-byte unchanged. Responsive adaptation did not delete, condense or rewrite their text.
- The legal source Markdown was rendered to HTML with authorized operator/address placeholder substitutions. The entire rendered document text was compared, not just headings. Privacy has 17 sections, 78 paragraphs and 25 list items; Terms has 24 sections, 98 paragraphs and 14 list items. No insertion placeholders remain. Original spelling, punctuation, legal assertions and paragraph/list order are preserved.
- Browser snapshots compare all main text elements, image source/alt attributes and internal/external anchor targets at 375, 390 and 768 against each page's 1440px DOM. Responsive presentation does not change those values. All four widths receive the same content, including hidden FAQ categories that are available through their controls.

## Explicitly authorized differences

1. Header becomes logo / Blog / For Physicians / Find My Treatment; mobile retains the visible treatment CTA and an accessible two-link menu. Footer destinations include FAQ, Clinical Research, Privacy Policy, Terms of Service and Contact.
2. Homepage titles become exactly Bimatoprost 1%, Finasteride + Melatonin and Tofacitinib 3%; the three supplied descriptions are unchanged.
3. Product depictions use the two supplied authentic photos and resized display derivatives. Original PNGs are retained byte-for-byte. Printed labels/artwork are not edited. Standard is used on public patient/product references; the physician photo containing tofacitinib 3% is used on the physician hero. Existing people and follicle artwork are cropped for presentation only, without generating replacement images.
4. Physician-directed CTA links route to `/physician-inquiry/`. Dr. Robert Hashemiyoon profile links use the new supplied reference. Existing study links/prose are preserved; unsupported medical corrections are not silently applied.
5. Full legal documents replace the previous placeholder legal page. Public operator/address/contact data follows the owner instructions.
6. Contact-page hero and paragraphs that were outside `<main>` in the original source and omitted by the previous export are restored verbatim. Only the explicitly confirmed public contact address is substituted. A source-based four-field physician preview and privacy links/calendar reference are added as requested, with visual/integration limitations reported.
7. The original bibliography audit supporting page is restored without discarding its source content. `/order.html` retains existing order-information content and no automatic redirect to a nonworking inquiry is activated.
8. Non-www confirmed canonical URLs, article canonical entities and unique supporting-page metadata are added without changing medical body prose. All existing noindex/robots restrictions remain.

`AUTHORIZED_CHANGE_REGISTER.json` and `MODIFIED_FILES.txt` provide implementation details. Missing expanded homepage copy, conflicting FAQ references and inquiry-design gaps are held as described in PENDING_ITEMS.md; they are not represented as completed approved content.
