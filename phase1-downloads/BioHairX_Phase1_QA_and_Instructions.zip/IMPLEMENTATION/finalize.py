from pathlib import Path
import csv,hashlib,html,json,shutil,zipfile
from PIL import Image,ImageDraw
ROOT=Path(__file__).parent;D=ROOT/'delivery';PUB=D/'public_html';REP=D/'reports';REVIEW=D/'REVIEW';BASE=ROOT/'baseline'
browser=json.loads((REP/'browser-results.json').read_text());audit=json.loads((REP/'audit-results.json').read_text());axe=json.loads((REP/'accessibility-results.json').read_text());routes=json.loads((ROOT/'routes.json').read_text())
assert len(browser['pages'])==80 and len(routes)==20
assert all(x['httpStatus']==200 and not x['bodyOverflow'] and not x['brokenImages'] and not x['httpErrors'] and x['desktopMobileContentEqual'] for x in browser['pages'])
assert all(x['passed'] for x in browser['functional']) and not browser['javascript_errors']
assert not audit['local_link_errors'] and not audit['content_preservation_failures'] and not audit['page_structure_errors']
assert all(not x['violations'] for x in axe)
lh={label:json.loads((REP/f'lighthouse-home-{label}.report.json').read_text()) for label in ['mobile','desktop']}
def writecsv(name,rows):
    with (REP/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
checklist=[]
for route in routes:
    for x in [r for r in browser['pages'] if r['route']==route]:
        checklist.append({'route':route,'width':x['width'],'http':'PASS','no_horizontal_overflow':'PASS' if not x['bodyOverflow'] else 'FAIL','images':'PASS' if not x['brokenImages'] else 'FAIL','content_images_links_equal_desktop':'PASS' if x['desktopMobileContentEqual'] else 'FAIL','visible_mobile_treatment_cta':'PASS' if x['visibleTreatment'] else 'FAIL','header_menu':'Blog | For Physicians','screenshot':'REVIEW/'+x['screenshot'],'content_reference_limits':'See PENDING_ITEMS.md; no approved copy invented'})
writecsv('RESPONSIVE_QA_CHECKLIST.csv',checklist)
modified=[]
for p in sorted(PUB.rglob('*')):
    if p.is_file():
        old=BASE/p.relative_to(PUB)
        if not old.exists() or old.read_bytes()!=p.read_bytes():modified.append({'path':str(p.relative_to(PUB)),'change':'modified' if old.exists() else 'added','bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
writecsv('MODIFIED_FILES.csv',modified);(REP/'MODIFIED_FILES.txt').write_text('\n'.join(x['path'] for x in modified)+'\n')
auth=[]
for name in ['BioHairX_standard_actual.png','BioHairX_Plus_physician_actual.png']:
    s=ROOT/'handoff/02_HOMEPAGE_VISUAL_AND_PRODUCT_ASSETS'/name;p=PUB/'assets/authentic'/name
    assert s.read_bytes()==p.read_bytes()
    auth.append({'file':name,'source_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'delivered_original_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'printed_labels_unmodified':True})
writecsv('AUTHENTIC_PRODUCT_VERIFICATION.csv',auth)
sourcehash=hashlib.sha256((ROOT/'BioHairX_FINAL_Codex_Phase1_Handoff.zip').read_bytes()).hexdigest();assert sourcehash=='90139be11ecf9438a47b656f6b0b0dfd29cf3929c967b9fbb4f46ae48f3ebc30'
baseline_robots=(BASE/'robots.txt').read_bytes();assert (PUB/'robots.txt').read_bytes()==baseline_robots
assert not (PUB/'order.html').read_text().lower().count('http-equiv="refresh"')
proof={'reassembled_sha256':sourcehash,'all_five_manifest_files_verified':True,'duplicate_part01_identical':True,'nested_implementation_source_and_research_archives_opened':True,'unchanged_robots':True,'legacy_order_redirect_not_activated':True,'github_head_unchanged':'6fa793c729da41bfa531acf44b689020dd621df1','no_github_push_or_deployment_performed':True}
(REP/'INPUT_AND_SCOPE_VERIFICATION.json').write_text(json.dumps(proof,indent=2))
performance=[]
for label,d in lh.items():
    performance.append({'target':'Homepage','profile':label,'performance':round(d['categories']['performance']['score']*100),'accessibility':round(d['categories']['accessibility']['score']*100),'best_practices':round(d['categories']['best-practices']['score']*100),'seo':round(d['categories']['seo']['score']*100),'lcp_ms':round(d['audits']['largest-contentful-paint']['numericValue']),'cls':d['audits']['cumulative-layout-shift']['numericValue'],'performance90_and_lcp2500_goal':d['categories']['performance']['score']>=.9 and d['audits']['largest-contentful-paint']['numericValue']<2500})
writecsv('LIGHTHOUSE_SUMMARY.csv',performance)
(REP/'QA_REPORT.md').write_text('''# Phase 1 QA — owner review build

## Verified results

- The reconstructed five-part ZIP matches the owner's exact SHA-256. Duplicate Part 1 was excluded. All manifest files and nested source/research ZIPs were verified and opened.
- **20 content pages × 4 widths = 80 completed browser/page checks**, with full-page PNG screenshots at **375, 390, 768 and 1440px**. This includes the complete homepage through footer, all three articles, research, physicians, patient/physician inquiry previews, FAQ, both complete legal pages, contact, ingredient pages, the source bibliography audit and the retained legacy order page.
- Every tested page returned HTTP 200; no broken images, page JavaScript errors or horizontal document overflow were found. Desktop/mobile semantic text, image sources/alt values and anchor targets match at all widths.
- All **18 functional checks passed**, including the visible mobile treatment CTA, two-link menu, Escape/focus restoration, exact three science cards, eight homepage FAQ questions, dedicated 13-slot FAQ controls, DOI search, research filters/reset/empty state, four disabled physician fields, honest callback/calendar status, complete legal section counts and no-JavaScript navigation/FAQ availability.
- axe-core WCAG 2 A/AA and WCAG 2.1 AA tags found **zero automated violations on all 20 content pages**. Incomplete checks are retained for manual follow-up; this is not a full accessibility certification.
- Existing compared page body content has **zero unapproved wording/order differences**, after allowing only the explicitly authorized science-card headings, source restoration, legal replacement and inquiry/privacy/calendar additions. All three article bodies/citations remain identical; all 29 current research records are byte-for-byte unchanged. The baseline is identified in CONTENT_PRESERVATION.md, not presented as proof that old pending copy had been approved.
- Privacy has **17 numbered sections, 78 paragraphs and 25 list items**. Terms has **24 numbered sections, 98 paragraphs and 14 list items**. Entire rendered text matches the supplied legal source after authorized placeholder substitutions; no `[INSERT ...]` fields remain.
- Non-www `https://biohairxrx.com` canonicals are configured. The retained `/order.html` information page canonicalizes to `/order-information/`; no premature inquiry redirect was activated. Indexing restrictions remain in place. No analytics, advertising pixels, Search Console activation or sitemap submission occurred.
- Local links and anchors pass. The prior 31 external URLs were newly attempted; all 34 total external checks remain unresolved due to enforced proxy policy. They are not marked verified or treated as broken because of policy denial.

## Lighthouse measurements

| Homepage profile | Performance | Accessibility | Best practices | SEO | LCP | CLS |
|---|---:|---:|---:|---:|---:|---:|
'''+''.join(f"| {x['profile']} | {x['performance']} | {x['accessibility']} | {x['best_practices']} | {x['seo']} | {x['lcp_ms']/1000:.2f}s | {x['cls']:.3f} |\n" for x in performance)+'''
The homepage met the stated laboratory performance goal of 90+ and LCP under 2.5s in these runs. Lighthouse was not run for all 20 pages. SEO's 69 score includes intentional staging noindex/robots restrictions; those restrictions were not removed to improve a score. These are local simulated laboratory results, not production field Core Web Vitals or a guarantee of mobile-network performance. Raw JSON and HTML reports are included.

## Fixes made during QA

The first no-JavaScript mobile menu check failed; an explicit fallback rule fixed it. The first mobile LCP measurement was 2.6s; product srcset sizing/loading priority reduced unnecessary image transfer while retaining authentic printed artwork. A favicon derivative removed a browser 404. The final 80-check run and both Lighthouse runs reflect those corrections.

## Held / untested work

Exact expanded homepage ingredient copy, the conflicting eight-question visual, missing dedicated FAQ copy and definitive standalone inquiry designs are not certified complete; the affected source-dependent parts were held rather than invented. PENDING_ITEMS.md records the differences and required owner input.

Forms, callback delivery and calendar booking are not operational or end-to-end tested. Profile/publisher live links remain unverified. Safari, Firefox, physical devices, screen readers, cPanel/Apache routing, field performance, legal correctness and clinical peer review were not tested. No production system or GitHub branch was changed.

## Evidence

RESPONSIVE_QA_CHECKLIST.csv; browser-results.json; accessibility-results.json; CONTENT_DIFF.csv; ARTICLE_PRESERVATION.csv; LEGAL_VERBATIM_CHECK.csv; CITATION_CONTEXT_REGISTER.csv; LINK_REGISTER.csv; EXTERNAL_LINK_CHECKS.csv; SEO_PAGE_REGISTER.csv; MODIFIED_FILES.csv; AUTHENTIC_PRODUCT_VERIFICATION.csv; Lighthouse HTML/JSON; and the 80 actual screenshot files.
''')
(REP/'SEO_AND_CITATION_QA.md').write_text('''# SEO, citations and interlinking — Phase 1

Confirmed canonical origin is `https://biohairxrx.com`, without www. Existing primary titles/descriptions and visible H1s are preserved; new legal/inquiry/support metadata is unique by canonical page. `/order.html` remains an information page with canonical `/order-information/` and no inquiry redirect while delivery is unavailable. Existing noindex/robots controls remain; no sitemap was submitted and no search/analytics service was activated.

All three article BlogPosting objects parse, use the confirmed canonical entity and retain supplied citation URLs. No reviewer identity, authorship, endorsement or publication day was invented. Official external rich-result validation was not reached.

Physician-directed CTAs now lead to `/physician-inquiry/`, distinct from `/find-my-treatment/`. Footer links reach FAQ, research, both legal documents and contact. Article prose is unchanged. Existing non-self related-article lists were checked; no mismatched blog cross-link was guessed or changed merely to force a passing result. Both original downloadable article PDFs and citation ordering are retained.

`CITATION_CONTEXT_REGISTER.csv` reopens all 17 source PDFs and associates the existing record title, author field, DOI, local summary and limitations with the appropriate source. DOI appearance in a PDF is evidence of occurrence, not blanket proof of every clinical claim. Khidhir primary full text and other pending primary sources remain pending as previously labeled. A supplied PDF containing adjacent unrelated research letters is not treated as one combined clinical study. Later owner-supplied Christiano/tofacitinib papers were not invented or added.

Scalp pharmacokinetics is not a human regrowth outcome; a 529% deposition finding is not BioHair X efficacy; oral tofacitinib findings do not establish topical 3% efficacy; LATISSE eyelash approval does not establish scalp approval; concentration, patient population, route and formulation distinctions remain in the existing evidence boundaries. Conflicting older physician/date/claim text was flagged, not rewritten under a responsive-only authorization.

All previous 31 external URLs were newly attempted in this task, plus the current new profile, calendar and website reference URLs (34 distinct total). The enforced proxy denied them. EXTERNAL_LINK_CHECKS.csv records current failures and marks them unresolved. Neither the two physician profiles nor the calendar are claimed valid/operational on the basis of appearing in the handoff.
''')
gallery='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>BioHair X Phase 1 screenshot index</title><style>body{font:16px/1.5 Arial;margin:30px;color:#142951;background:#f0f6fc}section{background:white;border:1px solid #cfe0f1;padding:20px;border-radius:9px;margin:20px 0}.grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:15px}img{width:100%;height:400px;object-fit:contain;object-position:top}a{color:#0052d4}small{display:block}h1,h2{font-family:Georgia}@media(max-width:800px){.grid{grid-template-columns:repeat(2,minmax(0,1fr))}}</style></head><body><h1>BioHair X — Phase 1 screenshot index</h1><p>80 actual Chromium full-page screenshots: 20 content pages at all four requested widths. Open each image at native resolution for full text. Long legal/research/bibliography screenshots are intentionally full-page.</p><p><a href="../reports/QA_REPORT.md">QA report</a> · <a href="../reports/PENDING_ITEMS.md">Held content and integration items</a></p>'
index=[]
for route in routes:
    gallery+='<section><h2>'+html.escape(route)+'</h2><div class="grid">'
    for x in sorted([p for p in browser['pages'] if p['route']==route],key=lambda p:p['width']):
        file=REVIEW/x['screenshot'];assert file.exists()
        gallery+=f'<a href="{x["screenshot"]}"><img src="{x["screenshot"]}" alt="{html.escape(route)} full-page screenshot at {x["width"]} pixels"><small>{x["width"]}px · full page</small></a>'
        index.append({'route':route,'width':x['width'],'file':x['screenshot'],'height':x['height'],'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
    gallery+='</div></section>'
gallery+='</body></html>';(REVIEW/'index.html').write_text(gallery);writecsv('SCREENSHOT_INDEX.csv',index)
# Overview sheets show the first viewport, not a substitute for full-page screenshots.
main=['/','/blog/','/for-physicians/','/find-my-treatment/','/physician-inquiry/','/faq/','/privacy/','/terms/','/clinical-research/']
for width in [375,390,768,1440]:
    tw,th=(350,260) if width>=768 else (240,520)
    sheet=Image.new('RGB',(3*(tw+20),3*(th+40)),'#e9f1f9');draw=ImageDraw.Draw(sheet)
    for i,route in enumerate(main):
        x=next(x for x in browser['pages'] if x['route']==route and x['width']==width);im=Image.open(REVIEW/x['screenshot']).convert('RGB');im=im.crop((0,0,im.width,min(im.height,1000 if width>=768 else 844)));im.thumbnail((tw,th));left=(i%3)*(tw+20)+10;top=(i//3)*(th+40)+30;sheet.paste(im,(left,top));draw.text((left,top-22),route,fill='#102c4a')
    sheet.save(REVIEW/f'overview-{width}.jpg',quality=91)
kit=D/'IMPLEMENTATION';kit.mkdir(exist_ok=True)
for name in ['implement.py','phase1.css','qa.py','audit.py','finalize.py']:shutil.copy2(ROOT/name,kit/name)
(kit/'README.md').write_text('''# Phase 1 local implementation provenance

Scripts use the verified extracted handoff and the previous delivered ZIP as baseline; no production system or Git checkout is used for writes. Paths are local to this task. Python development tools used: BeautifulSoup4, Markdown, Pillow, PyMuPDF and Playwright; Chromium and local axe-core/Lighthouse provide browser QA. The deployed static files require none of these tools.

Input and baseline folders remain outside public_html. Do not use these scripts to publish. Use the existing isolated cloud workspace; do not create a Git worktree unless explicitly requested. Rebuilding generates local review output and does not resolve missing owner-approved content automatically.
''')
(D/'README.md').write_text('''# BioHair X — Phase 1 local review artifacts

Prepared without deployment, GitHub push, production edits or indexing/analytics activation.

- `public_html/`: revised static local review site.
- `REVIEW/index.html`: screenshot gallery; all 20 pages at 375, 390, 768 and 1440px.
- `reports/QA_REPORT.md`: measured results and test boundaries.
- `reports/PENDING_ITEMS.md`: exact-content, design and integration items held for owner review.
- `reports/MODIFIED_FILES.csv`: full file list and hashes.
- `reports/CONTENT_PRESERVATION.md`: baseline, authorized differences and exact text checks.
- `LOCAL_REVIEW.md`: local review instructions; stop after Phase 1.

The legal pages contain the complete owner-supplied 17/24-section documents. Authentic product PNGs are retained unchanged. Current approved technical changes are implemented; ambiguous expanded ingredient/FAQ/inquiry design portions are not falsely certified complete. Forms and calendar booking remain unconnected/unverified.

This chat has no direct ZIP attachment/export capability. These artifacts are local files; no new external download copy was created under the no-push instruction.
''')
def zipfiles(files,dest,base):
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(files):z.write(p,str(p.relative_to(base)))
    with zipfile.ZipFile(dest) as z:assert z.testzip() is None
zipfiles([p for p in PUB.rglob('*') if p.is_file()],ROOT/'BioHairX_Phase1_Website.zip',PUB)
for width in [375,390,768,1440]:
    selected=list(REVIEW.glob(f'*-{width}.png'))+[REVIEW/f'overview-{width}.jpg']
    zipfiles(selected,ROOT/f'BioHairX_Phase1_Screenshots_{width}px.zip',REVIEW)
zipfiles([p for p in D.rglob('*') if p.is_file() and not p.is_relative_to(PUB) and not (p.is_relative_to(REVIEW) and p.suffix in ['.png','.jpg'])],ROOT/'BioHairX_Phase1_QA_and_Instructions.zip',D)
archives=sorted(ROOT.glob('BioHairX_Phase1_*.zip'))
(ROOT/'SHA256SUMS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.name+'\n' for p in archives))
for p in archives:print(p.name,round(p.stat().st_size/1024**2,2),'MiB')
print('Final checks passed: 80 screenshots, all 18 functional checks, full legal text, zero unauthorized baseline wording differences. Artifacts are local only.')
