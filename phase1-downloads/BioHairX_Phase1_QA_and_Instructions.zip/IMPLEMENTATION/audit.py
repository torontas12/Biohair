from pathlib import Path
import csv,json,re,hashlib,sys,time,urllib.request,urllib.error,urllib.parse,concurrent.futures,unicodedata
ROOT=Path(__file__).parent;sys.path[:0]=[str(ROOT/'tools'),'/workspace/bhx-implementation/tools']
from bs4 import BeautifulSoup
import markdown,fitz
BASE=ROOT/'baseline';PUB=ROOT/'delivery/public_html';REP=ROOT/'delivery/reports';HAND=ROOT/'handoff'
def parse(t):return BeautifulSoup(t,'html.parser')
def writecsv(name,rows,fields=None):
    with (REP/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
routes=json.loads((ROOT/'routes.json').read_text());docs={p:parse(p.read_text()) for p in PUB.rglob('*.html')};links=[];external=set();localerrors=[];pageissues=[];schemas=[]
for p,s in docs.items():
    page='/'+str(p.relative_to(PUB))
    for node in s.select('a[href],img[src],script[src],link[href]'):
        key='href' if node.name in ['a','link'] else 'src';u=node.get(key,'');q=urllib.parse.urlsplit(u)
        if q.scheme in ['http','https']:
            if key=='href' and node.name=='a':external.add(u)
            status='unresolved';detail='Independent remote check pending'
        elif q.scheme in ['mailto','tel']:
            status='reference';detail='Owner-specified public contact only; not a configured form delivery destination'
        elif q.scheme:status='unresolved';detail='Other URL scheme'
        else:
            path=urllib.parse.unquote(q.path);target=PUB/path.lstrip('/') if path.startswith('/') else p.parent/path if path else p
            if target.is_dir():target=target/'index.html'
            if not target.exists():status='broken';detail='Missing local target'
            elif q.fragment and target.suffix=='.html' and not docs.get(target,parse(target.read_text())).find(id=urllib.parse.unquote(q.fragment)):status='broken';detail='Missing local anchor'
            else:status='verified';detail='Local target/anchor checked'
        item={'page':page,'anchor_text':node.get_text(' ',strip=True) or node.get('alt','') or node.name,'target':u,'status':status,'evidence':detail};links.append(item)
        if status=='broken':localerrors.append(item)
    ids=[x['id'] for x in s.select('[id]')]
    if len(ids)!=len(set(ids)):pageissues.append({'page':page,'issue':'Duplicate IDs'})
    for t in s.select('script[type="application/ld+json"]'):
        try:
            d=json.loads(t.string);assert d['@type']=='BlogPosting' and d['mainEntityOfPage'].startswith('https://biohairxrx.com/');schemas.append({'page':page,'status':'JSON syntax and confirmed canonical entity checked','type':d['@type']})
        except Exception as e:pageissues.append({'page':page,'issue':'Schema: '+str(e)})
oldurls={r['url'] for r in csv.DictReader((HAND/'03_PREVIOUS_QA_REPORTS/reports/EXTERNAL_LINK_CHECKS.csv').open())}
external|=oldurls
def remote(url):
    start=time.monotonic()
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'BioHairX-Phase1-Independent-LinkAudit/1.0'}),timeout=12) as r:
            r.read(1024);return {'url':url,'status_code':r.status,'final_url':r.url,'status':'verified','evidence':'Renewed HTTP response; bibliographic/context review separate','seconds':round(time.monotonic()-start,2),'previous31':url in oldurls}
    except urllib.error.HTTPError as e:
        return {'url':url,'status_code':e.code,'final_url':e.url,'status':'broken' if e.code in [404,410] else 'unresolved','evidence':str(e),'seconds':round(time.monotonic()-start,2),'previous31':url in oldurls}
    except Exception as e:return {'url':url,'status_code':'','final_url':'','status':'unresolved','evidence':str(e),'seconds':round(time.monotonic()-start,2),'previous31':url in oldurls}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:remotechecks=list(pool.map(remote,sorted(external)))
byurl={x['url']:x for x in remotechecks}
for row in links:
    if row['target'] in byurl:row['status']=byurl[row['target']]['status'];row['evidence']=byurl[row['target']]['evidence']
writecsv('LINK_REGISTER.csv',links);writecsv('EXTERNAL_LINK_CHECKS.csv',remotechecks)
# Exact content preservation against the previously delivered desktop implementation.
def atoms(soup):
    return [(n.name,n.get_text(' ',strip=True)) for n in soup.select('h1,h2,h3,h4,p,li,dt,dd,summary,label')]
diffs=[]
for route,rel in routes.items():
    p=PUB/rel;b=BASE/('order-information/index.html' if route=='/order.html' else rel)
    if not b.exists() or route in ['/privacy/','/terms/','/contact/','/physician-inquiry/','/bibliography-audit.html']:continue
    before=parse(b.read_text()).find('main');after=parse(p.read_text()).find('main')
    if route=='/':
        # The only authorized homepage text mutations are the two science-card headings.
        titles=['Bimatoprost 1%','Finasteride + Melatonin','Tofacitinib 3%']
        for card,title in zip(before.select('.home-section .ingredient'),titles):card.h3.string=title
    if route=='/find-my-treatment/':
        for x in after.select('.inquiry-privacy,.calendar-reference'):x.decompose()
    a=atoms(before);z=atoms(after)
    diffs.append({'route':route,'baseline_elements':len(a),'current_elements':len(z),'zero_unapproved_wording_changes':a==z,'details':'' if a==z else json.dumps({'before':a,'after':z},ensure_ascii=False)})
writecsv('CONTENT_DIFF.csv',diffs)
legal=[]
for route,name,count in [('/privacy/','PRIVACY_POLICY_FULL.md',17),('/terms/','TERMS_OF_SERVICE_FULL.md',24)]:
    corrected=(REP/name).read_text();expected=parse(markdown.markdown(corrected,extensions=['extra']));actual=parse((PUB/routes[route]).read_text()).select_one('.legal-copy')
    assert expected.get_text(' ',strip=True)==actual.get_text(' ',strip=True)
    assert len(actual.find_all('h2'))==count
    legal.append({'route':route,'numbered_sections':count,'exact_text_after_authorized_substitutions':True,'paragraphs':len(actual.find_all('p')),'list_items':len(actual.find_all('li')),'remaining_insert_placeholders':'[INSERT' in actual.get_text()})
writecsv('LEGAL_VERBATIM_CHECK.csv',legal)
# Preserve the latest implemented article prose and all research records byte-for-byte.
articlechecks=[]
for route,rel in routes.items():
    if route.startswith('/blog/') and route!='/blog/':
        old=parse((BASE/rel).read_text()).select_one('.article-body');new=parse((PUB/rel).read_text()).select_one('.article-body')
        articlechecks.append({'route':route,'article_prose_citations_order_unchanged':atoms(old)==atoms(new)})
assert all(x['article_prose_citations_order_unchanged'] for x in articlechecks)
datafile='research-data/publications.json';assert (BASE/datafile).read_bytes()==(PUB/datafile).read_bytes()
writecsv('ARTICLE_PRESERVATION.csv',articlechecks)
# Read primary PDFs anew; map the existing cards to the correct source, without rewriting medical prose.
papers=ROOT/'expanded/BioHairX_Master_Clinical_Research_Library_17_Papers(1)'
mapping={'01':'finasteride-safety','02':'caserini-dht','03':'jin','04':'bimatoprost-pk','05':'sardana','06':'chikhalkar','07':'subedi','08':'melatonin-mice','09':'jak-review','10':'zhang','11':'aga-network','12':'melatonin-review','13':'kennedy-crispin','14':'melatonin-2025','15':'finasteride-systematic','16':'zeppieri','17':'bayart'}
records={x['id']:x for x in json.loads((PUB/datafile).read_text())};citations=[]
normalize=lambda t:unicodedata.normalize('NFKD',t).replace('ﬁ','fi').replace('\u00ad','').lower()
for file in sorted(papers.rglob('*.pdf')):
    doc=fitz.open(file);text='\n'.join(p.get_text() for p in doc);key=mapping[file.name[:2]];record=records[key];doi=record.get('doi','')
    normalized=normalize(text);doimatch=bool(doi and normalize(doi) in normalized)
    citations.append({'record_id':key,'source_pdf':file.name,'pages':len(doc),'record_title':record['title'],'record_authors':record['authors'],'record_doi':doi,'doi_found_in_supplied_pdf':doimatch,'source_sha256':hashlib.sha256(file.read_bytes()).hexdigest(),'context':record['summary'],'limitation':record['limitations'],'verification':'Primary PDF reopened; DOI occurrence and study/context association checked; not blanket independent claim verification','unresolved':'No DOI in record; do not invent one' if not doi else ('DOI not found in extraction; manual source check required' if not doimatch else '')})
writecsv('CITATION_CONTEXT_REGISTER.csv',citations)
seo=[]
for route,rel in routes.items():
    s=parse((PUB/rel).read_text());seo.append({'route':route,'title':s.title.get_text(),'description':s.select_one('meta[name=description]')['content'],'h1':s.h1.get_text(' ',strip=True) if s.h1 else '', 'canonical':s.select_one('link[rel=canonical]')['href'],'indexability':s.select_one('meta[name=robots]')['content'],'status':'Phase 1 local review; indexing not activated'})
writecsv('SEO_PAGE_REGISTER.csv',seo)
assert all(x['canonical']=='https://biohairxrx.com'+('/order-information/' if x['route']=='/order.html' else x['route']) for x in seo)
assets=[]
for file in sorted(PUB.rglob('*')):
    if file.is_file():assets.append({'path':str(file.relative_to(PUB)),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()})
writecsv('ASSET_MANIFEST.csv',assets)
result={'page_count':len(routes),'local_link_errors':localerrors,'page_structure_errors':pageissues,'content_preservation_failures':[x['route'] for x in diffs if not x['zero_unapproved_wording_changes']],'article_preservation':articlechecks,'legal':legal,'renewed_previous31':sum(x['previous31'] for x in remotechecks),'external_url_count':len(remotechecks),'external_http_verified':sum(x['status']=='verified' for x in remotechecks),'external_unresolved':sum(x['status']=='unresolved' for x in remotechecks),'schemas':schemas,'primary_pdf_count':len(citations),'research_records_unchanged':True}
(REP/'audit-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
