from pathlib import Path
import csv,json,sys,hashlib,time
ROOT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'tools'),'/workspace/bhx-implementation/tools']
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright
PUB=ROOT/'delivery/public_html';REP=ROOT/'delivery/reports';REVIEW=ROOT/'delivery/REVIEW'
REVIEW.mkdir(exist_ok=True);routes=json.loads((ROOT/'routes.json').read_text())
results=[];errors=[];snapshots={};functional=[];accessibility=[]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    for width in [1440,768,390,375]:
        context=browser.new_context(viewport={'width':width,'height':1000 if width>390 else 844},device_scale_factor=1,reduced_motion='reduce')
        page=context.new_page();page.on('pageerror',lambda e:errors.append(str(e)))
        page.add_init_script('''window.__phase1={cls:0,lcp:0};new PerformanceObserver(l=>{for(const e of l.getEntries())if(!e.hadRecentInput)window.__phase1.cls+=e.value}).observe({type:'layout-shift',buffered:true});new PerformanceObserver(l=>{for(const e of l.getEntries())window.__phase1.lcp=e.startTime}).observe({type:'largest-contentful-paint',buffered:true});''')
        for route in routes:
            network_errors=[]
            def response(r):
                if r.status>=400:network_errors.append({'url':r.url,'status':r.status})
            page.on('response',response)
            start=time.monotonic();r=page.goto('http://127.0.0.1:8866'+route,wait_until='networkidle')
            page.evaluate('document.fonts.ready');page.locator('img').evaluate_all('(imgs)=>Promise.all(imgs.map(i=>i.decode().catch(()=>{})))')
            check=page.evaluate('''()=>{const main=document.getElementById('main');return {h1:main.querySelectorAll('h1').length,bodyOverflow:document.documentElement.scrollWidth>innerWidth,brokenImages:[...document.images].filter(i=>!i.complete||!i.naturalWidth).map(i=>i.src),visibleTreatment:!!document.querySelector('.header-treatment')&&getComputedStyle(document.querySelector('.header-treatment')).display!=='none',headerLinks:[...document.querySelectorAll('#main-nav a')].map(a=>a.textContent.trim()),height:document.documentElement.scrollHeight,overflowElements:[...main.querySelectorAll('*')].filter(e=>e.getBoundingClientRect().right>innerWidth+1&&getComputedStyle(e).position!=='absolute').slice(0,8).map(e=>({tag:e.tagName,cls:e.className,width:e.getBoundingClientRect().width})),text:[...main.querySelectorAll('h1,h2,h3,h4,p,li,dt,dd,summary,label')].map(e=>e.textContent.replace(/\\s+/g,' ').trim()),images:[...main.querySelectorAll('img')].map(e=>({src:e.getAttribute('src'),alt:e.getAttribute('alt')})),links:[...main.querySelectorAll('a')].map(a=>({text:a.textContent.trim(),href:a.getAttribute('href')})),vitals:window.__phase1}}''')
            content={k:check.pop(k) for k in ['text','images','links']}
            if width==1440:snapshots[route]=content
            check['desktopMobileContentEqual']=content==snapshots[route]
            filename=(route.strip('/').replace('/','__').replace('.html','') or 'home')+f'-{width}.png'
            page.screenshot(path=str(REVIEW/filename),full_page=True,animations='disabled')
            results.append({'route':route,'width':width,'httpStatus':r.status,'httpErrors':network_errors,'seconds':round(time.monotonic()-start,2),'screenshot':filename,**check})
            page.remove_listener('response',response)
            if width==1440:
                page.add_script_tag(path='/workspace/bhx-phase1/qa-tools/node_modules/axe-core/axe.min.js')
                axe=page.evaluate('''async()=>{const r=await axe.run(document,{runOnly:{type:'tag',values:['wcag2a','wcag2aa','wcag21aa']}});return {passes:r.passes.length,violations:r.violations.map(v=>({id:v.id,impact:v.impact,help:v.help,nodes:v.nodes.map(n=>({html:n.html,target:n.target,failureSummary:n.failureSummary}))})),incomplete:r.incomplete.map(v=>({id:v.id,nodes:v.nodes.length}))}}''')
                accessibility.append({'route':route,**axe})
        context.close()
    c=browser.new_context(viewport={'width':375,'height':844});page=c.new_page()
    page.goto('http://127.0.0.1:8866/')
    functional.append({'check':'Mobile header has visible treatment CTA and two menu links','passed':page.locator('.header-treatment').is_visible() and page.locator('#main-nav a').all_text_contents()==['Blog','For Physicians']})
    page.get_by_role('button',name='Menu',exact=True).click();functional.append({'check':'Mobile menu opens','passed':page.locator('#main-nav').is_visible()})
    page.keyboard.press('Escape');functional.append({'check':'Menu Escape and focus restoration','passed':not page.locator('#main-nav').is_visible() and page.locator('.menu-toggle').evaluate('e=>e===document.activeElement')})
    functional.append({'check':'Homepage exactly three approved science cards','passed':page.locator('.home-section .ingredient h3').all_text_contents()==['Bimatoprost 1%','Finasteride + Melatonin','Tofacitinib 3%']})
    functional.append({'check':'Homepage preserves eight FAQ questions','passed':page.locator('.faq-grid details').count()==8})
    page.goto('http://127.0.0.1:8866/faq/');page.locator('#faq-tab-0').focus();page.keyboard.press('ArrowRight');functional.append({'check':'FAQ tabs keyboard navigation','passed':page.locator('#faq-tab-1').get_attribute('aria-selected')=='true'})
    page.locator('#faq-panel-1 summary').first.focus();page.keyboard.press('Enter');functional.append({'check':'FAQ keyboard accordion','passed':page.locator('#faq-panel-1 details').first.get_attribute('open') is not None})
    functional.append({'check':'Dedicated FAQ preserves all 13 items','passed':page.locator('.faq-content details').count()==13})
    page.goto('http://127.0.0.1:8866/clinical-research/');page.locator('#research-search').fill('70710');functional.append({'check':'Research DOI search','passed':page.locator('.research-card:visible').count()==1})
    page.get_by_role('button',name='Reset',exact=True).click();page.wait_for_timeout(30);page.locator('#research-ingredient').select_option('melatonin');functional.append({'check':'Research ingredient filter','passed':page.locator('.research-card:visible').count()>0 and page.locator('.research-card:visible:not([data-ingredient="melatonin"])').count()==0})
    page.locator('#research-search').fill('zzznomatch');functional.append({'check':'Research empty state','passed':page.locator('#research-empty').is_visible()})
    page.get_by_role('button',name='Reset',exact=True).click();page.wait_for_timeout(30);functional.append({'check':'Research reset preserves 29 records','passed':page.locator('.research-card:visible').count()==29})
    page.goto('http://127.0.0.1:8866/physician-inquiry/');functional.append({'check':'Four physician fields disabled, distinct patient/physician routes','passed':page.locator('.phase1-inquiry-form input').count()==4 and page.locator('.phase1-inquiry-form input:disabled').count()==4})
    page.get_by_role('button',name='Request a callback',exact=True).click();functional.append({'check':'Callback reports missing integration, not success','passed':page.locator('#pending-dialog').is_visible() and 'not been configured' in page.locator('#pending-message').inner_text()});page.get_by_role('button',name='Close',exact=True).click()
    page.get_by_role('button',name='Schedule a call',exact=True).click();functional.append({'check':'Calendar status does not claim booking','passed':'not a verified' in page.locator('#pending-message').inner_text()});page.get_by_role('button',name='Close',exact=True).click()
    for route,number in [('/privacy/',17),('/terms/',24)]:
        page.goto('http://127.0.0.1:8866'+route);functional.append({'check':f'{route} complete numbered sections','passed':page.locator('.legal-copy h2').count()==number})
    c.close()
    c=browser.new_context(java_script_enabled=False,viewport={'width':375,'height':844});page=c.new_page();page.goto('http://127.0.0.1:8866/faq/')
    functional.append({'check':'Navigation and all FAQ groups readable without JavaScript','passed':page.locator('#main-nav').is_visible() and all(page.locator(f'#faq-panel-{i}').is_visible() for i in range(3))})
    c.close();browser.close()
(REP/'browser-results.json').write_text(json.dumps({'pages':results,'functional':functional,'javascript_errors':errors,'content_snapshots':snapshots},indent=2))
(REP/'accessibility-results.json').write_text(json.dumps(accessibility,indent=2))
failure=[x for x in results if x['bodyOverflow'] or x['brokenImages'] or x['httpStatus']!=200 or x['httpErrors'] or x['h1']!=1 or not x['desktopMobileContentEqual']]
print(json.dumps({'pageViewportChecks':len(results),'renderFailures':failure,'functionalFailures':[x for x in functional if not x['passed']],'javascriptErrors':errors,'axeViolations':[{'route':x['route'],'violations':x['violations']} for x in accessibility if x['violations']]},indent=2))
