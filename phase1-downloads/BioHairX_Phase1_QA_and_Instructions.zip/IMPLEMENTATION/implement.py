from pathlib import Path
import csv,copy,hashlib,html,json,re,shutil,sys
ROOT=Path(__file__).parent
sys.path[:0]=[str(ROOT/'tools'),'/workspace/bhx-implementation/tools']
from bs4 import BeautifulSoup
from PIL import Image
import markdown
BASE=ROOT/'baseline';PUB=ROOT/'delivery/public_html';REPORT=ROOT/'delivery/reports'
ASSETS=ROOT/'handoff/02_HOMEPAGE_VISUAL_AND_PRODUCT_ASSETS'
REPORT.mkdir(parents=True,exist_ok=True)
shutil.copytree(BASE,PUB,dirs_exist_ok=True)
AUTH=PUB/'assets/authentic';AUTH.mkdir(exist_ok=True)
for name in ['BioHairX_standard_actual.png','BioHairX_Plus_physician_actual.png']:
    shutil.copy2(ASSETS/name,AUTH/name)
    for width in [420,600,800]:
        im=Image.open(ASSETS/name).convert('RGB');im.thumbnail((width,width))
        im.save(AUTH/(Path(name).stem+f'-{width}.webp'),quality=92)
ref=ROOT/'handoff/01_EXISTING_IMPLEMENTATION_AND_SEO/01_REFERENCES/BioHairX_Revision_D_Faithful_Spacing_Review.png'
Image.open(ref).convert('RGB').crop((480,92,803,425)).save(PUB/'assets/phase1-hero-people.webp',quality=94)
pref=ROOT/'handoff/01_EXISTING_IMPLEMENTATION_AND_SEO/01_REFERENCES/BioHair X Physician Landing Page(2).png'
Image.open(pref).convert('RGB').crop((855,48,1024,316)).save(PUB/'assets/phase1-follicle.webp',quality=94)
DOMAIN='https://biohairxrx.com'
CALENDAR='https://calendar.google.com/calendar/embed?src=c_93de505c48843e142e190b885c93892d2b8ec34e155fff3f2b193ce49cc19474%40group.calendar.google.com&ctz=America%2FLos_Angeles'
routes=json.loads(Path('/workspace/bhx-implementation/page-register.json').read_text())
modified=[];changes=[]
def parse(s):return BeautifulSoup(s,'html.parser')
def route_for(path):
    if path.name=='index.html':return '/'+str(path.parent.relative_to(PUB)).strip('.') .strip('/')+'/' if path.parent!=PUB else '/'
    return '/'+str(path.relative_to(PUB))
def product_image(soup,physician=False,cls=''):
    stem='BioHairX_Plus_physician_actual' if physician else 'BioHairX_standard_actual'
    image=soup.new_tag('img',src=f'/assets/authentic/{stem}-800.webp')
    image['srcset']=f'/assets/authentic/{stem}-420.webp 420w, /assets/authentic/{stem}-600.webp 600w, /assets/authentic/{stem}-800.webp 800w'
    image['sizes']='(max-width: 560px) 60vw, 420px' if 'phase1-hero-product' in cls else '(max-width: 560px) 160px, 420px'
    if 'phase1-hero-product' in cls:image['fetchpriority']='high'
    image['width']='800';image['height']='725'
    image['alt']='Owner-supplied BioHair X bottle and carton photograph'+(' showing the physician formulation with tofacitinib 3%' if physician else ' showing the standard formulation without tofacitinib')
    if cls:image['class']=cls.split()
    return image
def header(soup,route):
    old=soup.select_one('.site-header');logo=copy.deepcopy(old.select_one('.brand'))
    h=parse('<header class="site-header phase1-header"><div class="container nav-inner"><div class="header-brand-slot"></div><nav id="main-nav" aria-label="Main navigation"><a href="/blog/">Blog</a><a href="/for-physicians/">For Physicians</a></nav><a class="button header-treatment" href="/find-my-treatment/">Find My Treatment <span aria-hidden="true">→</span></a><button class="menu-toggle" aria-expanded="false" aria-controls="main-nav" aria-label="Menu"><span aria-hidden="true">☰</span></button></div></header>')
    h.select_one('.header-brand-slot').replace_with(logo)
    for a in h.select('nav a'):
        if route==a['href'] or (a['href']=='/blog/' and route.startswith('/blog/')):a['aria-current']='page'
    old.replace_with(h)
def ensure_footer(soup):
    footer=soup.find('footer')
    required=[('/faq/','FAQ'),('/clinical-research/','Clinical Research'),('/privacy/','Privacy Policy'),('/terms/','Terms of Service'),('/contact/','Contact')]
    for b in list(footer.select('[data-pending]')):
        if 'terms' in b.get_text().lower():
            a=soup.new_tag('a',href='/terms/');a.string='Terms of Service';b.replace_with(a)
    target=footer.find('nav') or footer.select_one('.footer-grid>div:nth-child(3)') or footer
    for href,label in required:
        matches=footer.find_all('a',href=href)
        if not matches:
            a=soup.new_tag('a',href=href);a.string=label;target.append(a)
        elif href=='/terms/':
            for a in matches:a.string=label
def standard_shell(route,title,description,body):
    soup=parse((BASE/'faq/index.html').read_text())
    soup.body['class']=['phase1-utility']
    soup.title.string=title
    soup.select_one('meta[name=description]')['content']=description
    main=soup.find('main');main.clear();main.append(parse(body))
    return soup

# Restore the source contact page's hero and paragraphs: previous export omitted content outside <main>.
source_contact=ROOT/'expanded/BioHairX-Complete-Website-Review/website/contact.html'
source=parse(source_contact.read_text());body=''.join(str(x) for x in source.body.find_all('section',recursive=False))
contact=standard_shell('/contact/','Contact | BioHair X®','Contact BioHair X for consumer and professional inquiries.',f'<div class="container utility-page">{body}</div>')
for a in contact.select('main a[href^="mailto:"]'):
    a['href']='mailto:info@BioHairXRx.com?subject=BioHair%20X%20Information%20Request'
(PUB/'contact/index.html').write_text(str(contact))
changes.append({'file':'contact/index.html','authorization':'Restore original source paragraphs/hero previously omitted; owner-confirmed contact email','detail':'Original contact source sections retained in full; shared header/footer applied.'})

# Full legal Markdown; substitutions are restricted to the explicitly authorized placeholder fields.
legal_specs=[('privacy','PRIVACY_POLICY_FULL.md',17),('terms','TERMS_OF_SERVICE_FULL.md',24)]
legal_results=[]
for route,name,count in legal_specs:
    raw=(ROOT/'handoff/LEGAL'/name).read_text()
    replacements={'[INSERT EXACT LEGAL NAME OF ENTITY RESPONSIBLE FOR WEBSITE AND PERSONAL INFORMATION]':'Core Research Laboratories Inc.','[INSERT LEGAL ENTITY NAME]':'Core Research Laboratories Inc.','[INSERT EXACT LEGAL WEBSITE OPERATOR]':'Core Research Laboratories Inc.','[INSERT BUSINESS MAILING ADDRESS]':'20162 SW Birch Street, Newport Beach, CA 92660'}
    corrected=raw
    for old,new in replacements.items():corrected=corrected.replace(old,new)
    rendered=markdown.markdown(corrected,extensions=['extra'])
    assert len(re.findall(r'^## \d+\.',corrected,re.M))==count
    soup=standard_shell('/'+route+'/',('Privacy Policy' if route=='privacy' else 'Terms of Service')+' | BioHair X®',('Read the complete BioHair X Privacy Policy.' if route=='privacy' else 'Read the complete BioHair X Terms of Service.'),'<div class="container legal-page"><article class="legal-copy">'+rendered+'</article></div>')
    soup.body['class']=['phase1-legal']
    p=PUB/route/'index.html';p.parent.mkdir(exist_ok=True);p.write_text(str(soup))
    legal_results.append({'route':'/'+route+'/','source':name,'sections':count,'normalized_rendered_text_sha256':hashlib.sha256(parse(rendered).get_text(' ',strip=True).encode()).hexdigest(),'substitutions':[k for k in replacements if k in raw],'status':'Full document rendered, authorized placeholders substituted only'})
    changes.append({'file':str(p.relative_to(PUB)),'authorization':'Full owner-supplied legal documents and four approved identity/contact substitutions','detail':f'All {count} numbered sections, lists, paragraphs and notices preserved.'})
    (REPORT/name).write_text(corrected)

# Separate physician route: source form structure, with the four specifically requested fields.
original_phys=parse((ROOT/'expanded/BioHairX-Complete-Website-Review/website/physicians.html').read_text())
source_form=original_phys.select_one('.inquiry-form')
form=copy.deepcopy(source_form)
for child in list(form.find_all(recursive=False)):
    if child.name=='label' and child.get('for') not in ['inquiry-0','inquiry-1','inquiry-2','inquiry-3']:child.decompose()
    elif child.name!='label':child.decompose()
form['id']='physician-inquiry-form';form['aria-label']='Physician inquiry preview — delivery not configured';form['class']=['form','inquiry-form','phase1-inquiry-form']
labels=['Full name','Clinic / practice','Professional email','Phone']
for label,new in zip(form.find_all('label'),labels):
    for c in list(label.contents):
        if isinstance(c,str):c.extract()
    label.insert(0,new)
    field=label.find('input');field['disabled']='';field['autocomplete']='off'
physbody='<div class="container physician-inquiry-page"><section class="panel"><h1>Bring BioHair X® to Your Practice</h1><p>Learn more about physician-customized formulations, clinical research, and practice integration.</p>'+str(form)+'<div class="inquiry-options"><button class="button" data-pending="Physician callback delivery has not been configured or tested. No contact information is collected.">Request a callback</button><button class="button outline" data-pending="The supplied Google Calendar is an integration reference, not a verified appointment-booking service.">Schedule a call</button></div><p class="inquiry-status">Layout-only preview; fields are intentionally disabled until a secure inquiry backend is connected. Do not include patient information.</p><p><a href="/privacy/">Privacy Policy</a> · <a href="/terms/">Terms of Service</a></p><details class="calendar-reference"><summary>Shared calendar integration reference — booking unverified</summary><p><a href="'+html.escape(CALENDAR,quote=True)+'" rel="noopener noreferrer">Open the supplied Google Calendar reference</a></p><p>This link displays the supplied calendar reference. It does not confirm an appointment or submit a request.</p></details></section></div>'
phys=standard_shell('/physician-inquiry/','Physician Inquiry | BioHair X®','Professional inquiries about physician-directed BioHair X formulations and practice information.',physbody)
dest=PUB/'physician-inquiry/index.html';dest.parent.mkdir(exist_ok=True);dest.write_text(str(phys))
changes.append({'file':'physician-inquiry/index.html','authorization':'Separate physician inquiry route and four fields with callback/scheduling options','detail':'Existing source form structure reused. Standalone approved visual absent; route is a clearly identified working adaptation, not certified visually approved. No destination activated.'})

# Preserve the previously supplied bibliography audit as a supporting page rather than omitting it.
audit_source=ROOT/'expanded/BioHairX-Complete-Website-Review/website/bibliography-audit.html'
audit=parse(audit_source.read_text())
auditbody=str(audit.find('main')) if audit.find('main') else ''.join(str(x) for x in audit.body.find_all(recursive=False) if x.name not in ['header','footer','script'])
bibliography=standard_shell('/bibliography-audit.html',audit.title.get_text() if audit.title else 'Bibliography Audit | BioHair X®','Source bibliography provenance and verification status.',f'<div class="container bibliography-page">{auditbody}</div>')
(PUB/'bibliography-audit.html').write_text(str(bibliography))

product_names={'product-display.webp','assessment-bottle.webp','original-product.png','approved-home-product.png'}
for p in sorted(PUB.rglob('*.html')):
    soup=parse(p.read_text())
    if not soup.select_one('.site-header'):continue # legacy redirect fallbacks retain their contents
    route=route_for(p)
    header(soup,route);ensure_footer(soup)
    if route=='/':
        cards=soup.select('.home-section .ingredient')
        expected=[('Bimatoprost 1%','Supports longer, fuller-looking hair. Studied for its effects on the hair growth cycle and follicular activity.'),('Finasteride + Melatonin','Addresses hair thinning at the source. Helps reduce DHT and provides antioxidant support for a healthier scalp environment.'),('Tofacitinib 3%','Targets immune-related hair loss. Investigated for its role in immune pathways, including in conditions such as alopecia areata.')]
        assert len(cards)==3
        for card,(title,description) in zip(cards,expected):
            card.h3.string=title;assert card.p.get_text(' ',strip=True)==description
        hero=soup.select_one('.home-hero .hero-grid>img')
        visual=soup.new_tag('div',attrs={'class':'phase1-home-visual'})
        humans=soup.new_tag('img',src='/assets/phase1-hero-people.webp',alt='Existing approved man and woman hero artwork',width='323',height='333');humans['class']=['phase1-hero-people']
        visual.append(humans);visual.append(product_image(soup,False,'phase1-hero-product'));hero.replace_with(visual)
        changes.append({'file':'index.html','authorization':'Three approved science-card titles, authentic standard packaging and revised navigation','detail':'Card descriptions, section order, hero prose, four hair-concern photos and eight existing FAQ questions/answers preserved. Working image FAQ wording conflicts are held for owner review.'})
    if route=='/for-physicians/':
        hero=soup.select_one('.physician-hero .hero-grid>img')
        visual=soup.new_tag('div',attrs={'class':'phase1-physician-visual'})
        visual.append(product_image(soup,True,'phase1-hero-product'))
        follicle=soup.new_tag('img',src='/assets/phase1-follicle.webp',alt='Existing approved follicle illustration',width='169',height='268');follicle['class']=['phase1-follicle'];visual.append(follicle);hero.replace_with(visual)
        for a in soup.select('main a'):
            if 'Physician Inquiry' in a.get_text() or a.get('href')=='#inquiry':a['href']='/physician-inquiry/'
        for b in list(soup.select('main [data-pending]')):
            if 'Formulation' in b.get_text():
                a=soup.new_tag('a',href='/physician-inquiry/',attrs={'class':b.get('class',['button'])});a.string=b.get_text(' ',strip=True);b.replace_with(a)
        changes.append({'file':str(p.relative_to(PUB)),'authorization':'Authentic physician-formulation photo; physician-directed CTA routing','detail':'All existing physician prose retained; no clinical wording or concentration silently changed.'})
    for image in list(soup.select('main img')):
        if Path(image.get('src','')).name in product_names:image.replace_with(product_image(soup,route=='/for-physicians/','phase1-product-image'))
    for a in soup.select('main a[href]'):
        if a['href'] in ['https://elitehairinstitute.com/'] and ('robert' in a.parent.get_text(' ',strip=True).lower() or 'hashemiyoon' in a.parent.get_text(' ',strip=True).lower()):a['href']='https://roberthashemiyoon.com/'
    if route=='/find-my-treatment/':
        first=soup.select_one('.assessment-card')
        privacy=parse('<p class="inquiry-privacy"><a href="/privacy/">Privacy Policy</a> · <a href="/terms/">Terms of Service</a></p>');first.append(privacy)
        refblock=parse('<details class="calendar-reference"><summary>Shared calendar integration reference — booking unverified</summary><p><a rel="noopener noreferrer" href="'+html.escape(CALENDAR,quote=True)+'">Open the supplied Google Calendar reference</a></p><p>No appointment is confirmed by this link. Patient intake and physician inquiry destinations remain separate and unconfigured.</p></details>');soup.select_one('.integration-note').append(refblock)
    # No approved legacy /order.html redirect is activated while intake is unavailable.
    if route=='/order-information/':
        for a in soup.select('main a[href="/find-my-treatment/"]'):
            if 'physician' in a.get_text(' ',strip=True).lower():a['href']='/physician-inquiry/'
    # Self-referencing confirmed non-www canonicals without activating indexing.
    for old in soup.select('link[rel=canonical],meta[property="og:url"]'):old.decompose()
    canonical=soup.new_tag('link',rel='canonical',href=DOMAIN+route);soup.head.append(canonical)
    og=soup.new_tag('meta',attrs={'property':'og:url','content':DOMAIN+route});soup.head.append(og)
    if not soup.select_one('link[href="/assets/phase1.css"]'):
        soup.head.append(soup.new_tag('link',rel='stylesheet',href='/assets/phase1.css'))
    soup.head.append(parse('<noscript><style>.phase1-header #main-nav{display:flex!important}</style></noscript>'))
    # Unique utility-page metadata, retaining source H1 and paragraphs.
    description=soup.select_one('meta[name=description]')
    if route=='/contact/':description['content']='Contact BioHair X for consumer information and professional inquiries.'
    if route in ['/bimatoprost-hair-growth.html','/finasteride-hair-loss.html','/melatonin-hair-growth.html','/tofacitinib-hair-loss.html']:
        description['content']=soup.find('main').h1.get_text(' ',strip=True)+'. Read the supplied educational information and research references.'
    if route=='/order-information/':description['content']='Information for healthcare professionals about BioHair X formulation inquiries.'
    for script in soup.select('script[type="application/ld+json"]'):
        obj=json.loads(script.string);obj['mainEntityOfPage']=DOMAIN+route;script.string=json.dumps(obj)
    p.write_text(str(soup))

# A favicon derivative prevents browser errors while preserving the supplied logo artwork.
logo=Image.open(PUB/'assets/logo.png').convert('RGBA')
logo.thumbnail((64,64));logo.save(PUB/'favicon.ico',format='ICO',sizes=[(64,20)])

# Canonical legacy order behavior is deliberately preserved and held, not pointed at an untested form.
ht=(PUB/'.htaccess').read_text()
ht='\n'.join(line for line in ht.splitlines() if not (line.startswith('RewriteRule') and 'order' in line))+'\n'
(PUB/'.htaccess').write_text(ht)
(PUB/'order.html').write_text((PUB/'order-information/index.html').read_text())

shutil.copy2(ROOT/'phase1.css',PUB/'assets/phase1.css')
for p in PUB.rglob('*.html'):
    q=BASE/p.relative_to(PUB)
    if not q.exists() or p.read_bytes()!=q.read_bytes():modified.append(str(p.relative_to(PUB)))
for path in ['assets/phase1.css','.htaccess']:
    if path not in modified:modified.append(path)
for p in AUTH.iterdir():modified.append(str(p.relative_to(PUB)))
modified+=['assets/phase1-hero-people.webp','assets/phase1-follicle.webp']
(REPORT/'MODIFIED_FILES.txt').write_text('\n'.join(sorted(modified))+'\n')
(REPORT/'AUTHORIZED_CHANGE_REGISTER.json').write_text(json.dumps(changes,indent=2))
(REPORT/'legal-source-checks.json').write_text(json.dumps(legal_results,indent=2))
(ROOT/'routes.json').write_text(json.dumps({route_for(p):str(p.relative_to(PUB)) for p in PUB.rglob('*.html') if parse(p.read_text()).select_one('.site-header')},indent=2))
print('Phase 1 pages:',len(json.loads((ROOT/'routes.json').read_text())),'Modified files:',len(modified),'Legal sections:',[x['sections'] for x in legal_results])
