# Phase 1 local implementation provenance

Scripts use the verified extracted handoff and the previous delivered ZIP as baseline; no production system or Git checkout is used for writes. Paths are local to this task. Python development tools used: BeautifulSoup4, Markdown, Pillow, PyMuPDF and Playwright; Chromium and local axe-core/Lighthouse provide browser QA. The deployed static files require none of these tools.

Input and baseline folders remain outside public_html. Do not use these scripts to publish. Use the existing isolated cloud workspace; do not create a Git worktree unless explicitly requested. Rebuilding generates local review output and does not resolve missing owner-approved content automatically.
