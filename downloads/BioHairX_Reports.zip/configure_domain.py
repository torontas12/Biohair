#!/usr/bin/env python3
"""Set a confirmed domain in an OFFLINE copy. This does not publish or enable indexing."""
from pathlib import Path
import argparse,csv,html,json,re,urllib.parse,xml.etree.ElementTree as ET
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('origin',help='Confirmed production HTTPS origin, without path')
p.add_argument('--root',type=Path,default=Path(__file__).parent)
a=p.parse_args();u=urllib.parse.urlsplit(a.origin)
if u.scheme!='https' or not u.hostname or u.username or u.password or u.path not in ['', '/'] or u.query or u.fragment:
 p.error('Supply only the confirmed HTTPS origin, without credentials, query or path.')
origin=a.origin.rstrip('/');pub=a.root/'public_html';register=a.root/'reports/SEO_PAGE_REGISTER.csv'
with register.open() as f:rows=list(csv.DictReader(f))
ET.register_namespace('', 'http://www.sitemaps.org/schemas/sitemap/0.9')
urls=ET.Element('{http://www.sitemaps.org/schemas/sitemap/0.9}urlset')
for row in rows:
 url=origin+row['path'];f=pub/row['path'].lstrip('/')/'index.html';s=f.read_text()
 s=re.sub(r'<link\b[^>]*rel=["\x27]canonical["\x27][^>]*>','',s,flags=re.I)
 s=re.sub(r'<meta\b[^>]*property=["\x27]og:url["\x27][^>]*>','',s,flags=re.I)
 s=re.sub(r'<meta\b[^>]*property=["\x27]og:image["\x27][^>]*>','',s,flags=re.I)
 s=s.replace('</head>',f'<meta property="og:image" content="{html.escape(origin,quote=True)}/assets/product-display.webp"><link rel="canonical" href="{html.escape(url,quote=True)}"><meta property="og:url" content="{html.escape(url,quote=True)}"></head>')
 f.write_text(s);row['final_live_url']=url;row['canonical']=url;row['status']='Domain configured offline; staging noindex retained; publication approval pending'
 node=ET.SubElement(urls,'{http://www.sitemaps.org/schemas/sitemap/0.9}url');ET.SubElement(node,'{http://www.sitemaps.org/schemas/sitemap/0.9}loc').text=url
with register.open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
ET.ElementTree(urls).write(pub/'sitemap.xml',encoding='utf-8',xml_declaration=True)
print('Configured canonical URLs, og:url and the nine-page sitemap. Staging noindex remains enabled. No deployment performed. Rebuild ZIP and rerun QA before a separately approved launch.')
