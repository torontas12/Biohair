# Deployment and rollback — instructions only

**Nothing has been deployed. The supplied ZIP is a staging review build and is intentionally blocked from indexing. Do not replace the live site until all launch blockers are resolved and the owner explicitly authorizes publication.**

## Local review

Extract `public_html.zip` into a separate folder. Its root contains `index.html`, `.htaccess`, assets and route directories; there is no extra enclosing `public_html/` directory inside the ZIP. Run `python3 -m http.server 8000 --directory public_html` from the delivery folder after extraction. Python is a review tool only; production hosting serves plain HTML/CSS/JS and needs no Node runtime or database. A local simple server uses HTML route fallbacks and does not validate Apache 301/header behavior.

## Before a separately approved launch

1. Resolve `reports/OPEN_ISSUES.md`: production domain and live route inventory; medical/content approvals; all 13 FAQ items; patient/image permissions; legal/contact content; article redistribution; form and booking service configuration.
2. Configure the **confirmed** domain in an offline copy using `python3 configure_domain.py CONFIRMED_HTTPS_ORIGIN`. This inserts the nine absolute canonicals and og:url values and writes the nine-URL sitemap. It deliberately retains staging noindex. The script does not connect to hosting or publish anything. Recheck `reports/SEO_PAGE_REGISTER.csv` and rebuild the upload ZIP after any changes.
3. Test every form/booking endpoint in an authorized test mode, including consent, success and failure handling. Do not collect health data in the present preview. Replace pending buttons only after destinations are verified. Review privacy/terms accordingly.
4. Recheck all external research/CTA URLs outside the restricted environment. Validate schema with the relevant official validators and review medical dates, author/reviewer identity and permissions.
5. Use a **private staging document root**, with hosting password protection where available. `noindex` and robots.txt do not provide access control. Confirm the actual domain document root in cPanel; it may differ from the default `public_html`. Test `.htaccess`, legacy 301s, assets, anchors, noindex headers and responsive layouts on that staging host. No Apache server was available during local validation.
6. Obtain explicit owner authorization for the exact approved build and target. Only then prepare the production indexing changes: remove the noindex meta directives and Apache X-Robots-Tag rule; replace staging robots disallow with the approved production crawl policy and real sitemap URL. Do not make production indexable while pending content remains.

## cPanel upload procedure after authorization

1. Download a dated full backup of the current document root, including hidden files such as `.htaccess`, permissions and any application configuration. Export any separately hosted forms/data if applicable. Record the current routing rules and hosting settings. Store the backup outside the public document root and confirm it can be read.
2. Upload the **approved, revalidated** ZIP to a separate folder first; extract and verify contents, hashes and hidden files. Never assume this staging ZIP is automatically approved for production.
3. Merge/replace the authorized static files in the confirmed document root. Preserve unrelated server-side applications and user data; do not delete unknown directories. Apply the reviewed redirect rules without discarding existing required hosting rules.
4. Check all nine primary URLs and retained historical URLs over HTTPS; verify expected 200/301 responses, correct canonicals, sitemap and approved indexing policy. Test CSS/JS/images/PDF downloads, FAQ keyboard behavior, mobile menu, research filters, secure form delivery and calendar behavior. Inspect error logs.
5. Record deployed archive hash, time, destination and approval. Submit sitemap / use Search Console only after a separately approved public launch and verified indexing settings.

## Rollback

If pages, assets, routes or integrations fail, return the previous backed-up files and original `.htaccess` to the same document root, restoring original permissions/configuration. Restore only data actually changed by the deployment, using the relevant service's supported procedure. Recheck the previously working URLs and forms and inspect logs. Retain the failed build separately for diagnosis. The backup/restore procedure has not been exercised on the live host because production access and deployment were outside scope.
