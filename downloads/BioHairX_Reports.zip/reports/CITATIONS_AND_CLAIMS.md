# Citations, evidence and claims review

The original 23 publication records remain available and carry their original verification limits where a primary paper is still missing. Six additional source-backed records bring the library to 29. All 17 research-library PDFs open and their text can be extracted; their filenames, lengths, hashes and extracted DOI candidates appear in `RESEARCH_PDF_INVENTORY.csv`. DOI candidates include references inside papers and are not automatically treated as the paper's own DOI.

Primary-source title/abstract/design checks were used for the new 2026 scalp bimatoprost pharmacokinetic record, the experimental Subedi delivery paper, melatonin reviews and mouse study, finasteride reviews, JAK review, network meta-analysis, Bayart pediatric letter and matching existing records. Existing source-verified Piraccini, Chikhalkar, Sardana, Jin and Purohit records retain source attribution. This is a targeted source audit, not independent clinical peer review or exhaustive replication of every calculation.

## Important source distinctions

- **Khajeh pour 2026, DOI 10.1111/cts.70710:** supplied primary PDF describes local exposure and tolerability of two 1% bimatoprost preparations in 11 men over 14 days. It does not measure clinical hair regrowth or establish efficacy in women or long-term safety.
- **Subedi 2022, DOI 10.1080/10717544.2022.2027046:** ex vivo skin delivery and preclinical experiments. The 529% deposition figure is not 529% human regrowth and is not a BioHair X result.
- **Khidhir 2013, DOI 10.1096/fj.12-218156:** exact title recovered from the supplied Zeppieri review's reference 349: 'The prostamide-related glaucoma therapy, Bimatoprost, offers a novel approach for treating scalp alopecias.' Primary full text is not in the 17-paper set. The scalp follicle/animal distinction is maintained; primary review remains pending.
- **Piraccini, DOI 10.1111/jdv.17738:** online 2021 / journal issue 2022. Specific topical spray and oral comparator; systemic absorption is not zero. Different vehicles/concentrations and combined products cannot be assumed equivalent.
- **Jin 2026, DOI 10.1111/cts.70544:** oral tofacitinib retrospective cohort for alopecia areata, distinct from bimatoprost and topical BioHair X.
- **Chikhalkar 2024:** small 2% topical tofacitinib study, not validation of 3% finished combination.
- **Greco 2024, DOI 10.3390/ijms25105167:** review, not an original 2016 trial. Source screenshot dates conflict and are reported rather than silently treated as fact.
- **Bayart / `17_showPdf.pdf`:** the file contains adjacent unrelated research letters as well as the pediatric JAK case series. Only the relevant letter/table supports the Bayart card. The neighboring photoprotection and DPCP text is not mislabeled as a BioHair X study.
- **Melatonin reviews / mouse work:** distinct sources, routes and levels of evidence are retained. The underlying 40-woman trial's primary paper is not supplied; the related original record stays pending rather than becoming primary-verified.

## External access and rights

All 31 distinct external URLs used by the rendered website were attempted with HTTPS verification enabled. Proxy tunnel responses were 403 Forbidden. None was successfully reached in this environment, and no remote destination is labeled broken solely because of a policy denial. Check `EXTERNAL_LINK_CHECKS.csv`; verify live resolution and bibliographic metadata before publication. The 427 URL occurrences extracted from source documents are separately inventoried in `SOURCE_LINK_INVENTORY.csv`; they are not all claimed to have been live-tested.

No publisher research PDFs are hosted in `public_html/`. Three owner-supplied educational articles are included as requested, with unchanged originals; owner confirmation of distribution rights remains pending. Open-access notices in a source do not replace a record of the applicable license and attribution requirements.

## Medical and commercial approvals still needed

The homepage and physician reference contain efficacy, before/after, credential and practice-benefit wording that has not been substantiated by this build. Keep staging private and obtain owner/qualified reviewer decisions on the conflicts in `OPEN_ISSUES.md`. The finished formulation is not established by ingredient papers, LATISSE eyelash approval does not extend to scalp use, topical tofacitinib for alopecia remains investigational, and finasteride reproductive precautions require review.
