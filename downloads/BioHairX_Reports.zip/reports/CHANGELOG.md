# Implementation changelog

- Verified all 12 input archives and 151 manifest files; implemented in a separate tree without modifying input source or the Git checkout.
- Built seven responsive design families across nine primary URLs and retained seven utility/history pages plus legacy redirects.
- Implemented the three complete article HTML pages using geometry-aware source PDF extraction; retained unchanged original PDF downloads and added source-to-section mappings.
- Retained every original publication record, added six source-backed records, corrected supported library metadata and added evidence boundaries, search, filtering, reset and stable anchors.
- Reproduced the designated Revision D and physician section sequences, with the exact approved formulation-request step and original supplied artwork.
- Added shared navigation, semantic headings, mobile menu, FAQ tabs/accordions, keyboard controls, pending-service dialogs, no-JavaScript fallbacks and print/reduced-motion behavior.
- Added SEO metadata, supported article schema, staging index controls, legacy route rules and an offline confirmed-domain configuration helper.
- Optimized display-image derivatives without regenerating source physician/product artwork or discarding originals.
- Captured actual browser screenshots and ran functional, content, asset, link, schema, responsive and axe-core checks. Fixed DOI-search coverage and four stale source anchors identified by testing.
- Documented all unresolved domain, integration, legal/medical, FAQ, permission and network-verification items. No live deployment occurred.
