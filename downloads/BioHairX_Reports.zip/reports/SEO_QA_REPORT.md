# SEO QA report

Seven design families produce nine primary HTML URLs. Science & Research is `/blog/`; Clinical Research is a separate `/clinical-research/` hub. All three article routes contain readable HTML and unchanged PDF downloads; PDFs are not substituted for articles.

- Nine titles and descriptions are unique; each primary page has one visible H1 and descriptive links. Source article titles and approved visible copy take priority over draft SEO proposals.
- Blog/article/research/physician/FAQ/treatment links connect the required content. Stable research anchors include the four specified SEO handoff anchors. Original records remain in crawlable HTML rather than depending on a JavaScript fetch.
- Three BlogPosting JSON-LD objects parse and use supported headlines and citation URLs. No reviewer identity, author credentials, publication day, rating, medical endorsement or finished-product trial is fabricated. No external Rich Results/schema service was reached; rich-result eligibility is not asserted.
- Open Graph title, description, type and site name are present. Confirmed-origin canonical, og:url and absolute og:image are pending domain confirmation; configure_domain.py adds them offline. Sitemap is intentionally empty until that step. No fake domain appears in the final website.
- All staging pages retain noindex, robots disallow and the proposed Apache X-Robots-Tag safeguard. The package must not be presented as a production-indexable launch build. Publication/indexing changes require owner authorization.
- Legacy routes are preserved with Apache redirect rules and static review fallbacks. Local HTML fallbacks were served; actual 301 responses and hosting override compatibility require private cPanel staging verification. Confirm indexed paths before finalizing redirects.
- Three original educational PDFs are offered as downloads. The proposed global staging noindex header also covers these on compatible Apache hosting. Before launch, keep PDF responses noindex via the reviewed production server configuration if needed to prevent competing PDF indexing; do not remove every PDF indexing safeguard blindly.
- Local link/anchor checks pass. External publisher and profile URL checks are unresolved because the network proxy blocked all 31 attempts. Medical citation accuracy is separately bounded in CITATIONS_AND_CLAIMS.md.

See SEO_PAGE_REGISTER.csv for all nine paths, metadata, H1, canonical and indexability status. No live URL or submitted sitemap is claimed.
