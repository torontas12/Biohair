# QA report — completed staging build

**Result: ready for local/staging review; publication remains blocked by the documented content, domain and integration decisions. No live site was modified.**

## Completed checks

| Check | Result |
|---|---|
| Input integrity | All 151 manifest inputs matched expected SHA-256 and byte lengths; no source files changed. |
| Primary routes | All nine URLs returned HTTP 200 in real Chromium at 1440px, 768px and 390px: 27 completed page/viewport checks. |
| Render integrity | No horizontal overflow, broken images, unlabeled inputs or page JavaScript errors in those checks. |
| Local resources | All 83 served files returned HTTP 200. 601 generated link/resource occurrences checked; zero missing local targets or anchors. |
| Interactions | All 11 functional checks passed: FAQ category click, arrow-key tabs, keyboard accordion, mobile menu open/Escape close, DOI search, ingredient filter, no-results state, reset, pending-service dialog and dialog close. |
| Progressive enhancement | Mobile navigation and all three FAQ categories available without JavaScript; all 29 research records remain present without JavaScript. |
| Accessibility automation | axe-core WCAG 2 A/AA and WCAG 2.1 AA tags: zero violations on all nine primary pages. Per-page passes/incomplete checks are retained in accessibility-results.json. |
| Articles | All 32 substantive sections across three articles matched source extraction after whitespace normalization. Editorial notes and ordered references retained. Original PDF download digests match. |
| SEO structure | Nine unique titles/descriptions, one H1 each, all three BlogPosting JSON-LD objects parse; unsupported authors/review dates omitted. |
| Staging indexing | noindex/nofollow meta on every primary page; robots.txt disallows crawling; Apache noindex header is configured but not live-host tested. |
| Canonical configuration helper | Tested in an isolated temporary copy; adds confirmed-origin canonicals, Open Graph URLs/image and nine sitemap entries while preserving noindex. No temporary test origin is in the delivered site. |
| Screenshots | 18 primary full-page screenshots (nine desktop + nine mobile), plus four FAQ category-state captures and two overview sheets. |

## Performance observations and scope

No external font, CSS framework, analytics or runtime API is required to render the site. Display derivatives of supplied product/physician imagery reduce transfer size while originals are retained. Images have dimensions, layouts reflow at mobile/tablet breakpoints, and reduced-motion/print preferences are supported.

Local Chromium observations recorded a maximum initial CLS of 0.000 and maximum observed LCP of 136 ms across these local runs. These unthrottled localhost measurements do **not** establish production Core Web Vitals, INP, mobile-network performance or Lighthouse scores. Metrics are preserved per run in browser-results.json.

## Unresolved or unrun checks

- Absolute canonical domain and final sitemap cannot be completed until the production origin is confirmed. The current sitemap is intentionally empty; no placeholder origin is shipped.
- All 31 external live URLs were attempted but blocked by proxy tunnel 403 responses. They are unresolved, not verified or declared broken. Uploaded primary PDFs support the separate source review.
- Intake, physician form delivery and calendar submission cannot be tested without approved services and destinations; they are not represented as working integrations.
- FAQ final wording/design, medical review, patient/physician/image permissions, terms/privacy/business contact and launch approval remain pending.
- Apache/cPanel execution, real legacy 301/header behavior, Safari/Firefox, screen-reader/real-device testing, Google Rich Results validation, production rollback and field performance were not executed.
- Automated accessibility tests do not replace manual assistive-technology or clinical/legal review. No pixel-perfect visual equivalence is claimed; see VISUAL_REVIEW.md.

Detailed evidence: browser-results.json, accessibility-results.json, final-checks.json, LOCAL_HTTP_CHECKS.csv, LINK_REGISTER.csv, ARTICLE_SOURCE_MAP.csv, INPUT_VERIFICATION.csv and the actual screenshot files.
