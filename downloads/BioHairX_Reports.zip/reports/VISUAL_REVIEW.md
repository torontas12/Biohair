# Visual review and deviations

Real Chromium full-page captures are in `REVIEW/` at 1440px and 390px for all nine primary URLs. Tablet width 768px was also tested. These are rendered website screenshots, not the supplied reference pictures repackaged as previews.

The build follows the references' blue/white palette, typography hierarchy, heroes, section sequence, bordered cards, article/sidebar composition and compact physician layout. Original source imagery and reference crops are reused; no replacement physician, patient, product label or full-page image was generated. Responsive layouts reflow columns into readable stacks with an accessible menu.

## Explicit deviations / pending design review

- Exact font files and vector logo assets were not supplied; local system Georgia/Arial and a source-logo crop are used. Low-resolution source crops remain limited by original quality. Some icon treatments use accessible simple symbols or source crops rather than a new illustration set.
- Desktop navigation is consolidated so all required destinations can be reached. Duplicate 'Blog' and 'Science & Research' destinations in mockups become one Science & Research item pointing to `/blog/`.
- Homepage uses the source physician photographs rather than replacing them with the different illustrated faces visible in Revision D. Identity and permissions remain pending. Press logos, result imagery and quotation are retained as reference content requiring substantiation.
- Blog has three real approved articles. Mockup-only article titles, dates, eight-page pagination and unsupported study-card metadata are not invented. Topic links point to available content.
- Research uses a full crawlable list of 29 records, making it longer than the illustrative reference; filters help locate studies. Cards show factual boundaries rather than asserting unverified clinical efficacy.
- The article reference's named reviewer, review dates, bookmark/share controls and unsupported credentials are not represented as working or verified. The article source PDFs govern title and prose. All three real articles have their own screenshots.
- Assessment service, booking and formulation CTAs open pending-status dialogs. Newsletter remains disabled. These controls do not simulate successful submissions.
- FAQ is a working implementation of the requested category structure. The board expressly has no approved FAQ screenshot; supplied standalone screenshots are of another company's site. Missing questions/answers are visibly pending. Layout and panel text therefore need final sign-off.
- Terms, privacy/business details, unresolved medical copy and rights remain explicitly documented. No claim of pixel-perfect equivalence or final owner approval is made.

`OPEN_ISSUES.md` lists the concrete launch decisions. Review screenshots at native resolution when checking body copy; contact sheets are only overview images.
