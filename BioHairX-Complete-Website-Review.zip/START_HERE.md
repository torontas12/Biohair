# BioHair X — complete integrated website review

One website, not separate sites or nested website ZIPs.

## Main pages
- `website/index.html` — latest homepage, refinement pass 2.
- `website/physicians.html` — current full-content physician page.
- `website/clinical-research.html` — Research & Clinical Evidence review draft.
- `website/bibliography-audit.html` — bibliography provenance and verification audit.

The shared site contains the original supporting pages, styles, JavaScript and assets. Links between the main pages are relative and stay within this one website. The physician and research pages share navigation; the homepage links to For Physicians, which links to Research. No extra installation, database or backend is required for local review.

After extracting the entire ZIP, open `website/index.html`, or run `python3 -m http.server 8000 --directory website` from the extracted directory. No deployment is authorized by these instructions.

## Screenshots and notes
`review/homepage/` contains the latest full-page homepage mobile/desktop screenshots and pass-2 notes. `review/physicians-research/` contains the four current physician/research screenshots, changes, source-preservation tests, browser checks and label/claim review notes. `reference-materials/` contains approved designs, original supplied artwork and research documents. These are references, not additional live websites or deployment instructions.

## Outstanding review items
The inquiry form is explicitly disabled until an approved backend is connected. Order Now leads to the existing informational inquiry page, not a live checkout. Research verification is partial: five supplied full-text publications checked; other references marked pending. The original label PDF lists three ingredients while the supplied carton and approved physician page list four. No labels, packaging or physician wording were silently corrected. The homepage retains its previously approved reference imagery; the new physician page uses the newer artwork supplied for that page.

Nothing has been deployed. The GitHub upload is a review-file transfer only. Do not publish the website without explicit sign-off.

## Suggested ChatGPT review request
Review this single website's homepage, physician page and Research & Clinical Evidence page against their approved references. Inspect the code and screenshots; verify claims against the included primary materials, flag incomplete verification and the label discrepancy, test navigation and responsive controls where possible, and return prioritized corrections. Do not generate product artwork, silently rewrite approved physician copy, invent research metadata, or deploy anything.
