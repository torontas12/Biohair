# Biohair — Working Knowledge Base & Product History
Updated: 23 October 2026

## Source record
**Document:** `Specs_TPP40336 (1).docx`, titled *Methods and Compositions for Inducing and Enhancing Hair Growth* (five-page invention-style specification). The file does not establish filing date, inventor, patent application number, grant status, ownership, commercial launch date, or a demonstrated clinical result. These remain unverified.

## Product identity and commercial status
**Biohair** is described by its seller as a **currently sold** hair-growth product. Its precise marketed ingredients, strengths, labeling, manufacturing specifications, authorization status, and intended claims have not yet been supplied or verified. The uploaded invention specification is relevant technical background, **not confirmation of Biohair's actual commercial formula**.

## Documented formulation concept
The specification proposes a topical hair-growth composition with two principal active ingredients:
- **Bimatoprost**, a prostaglandin analogue.
- **Tofacitinib**, a Janus kinase (JAK) inhibitor.

It identifies possible supplementary ingredients including **melatonin, azelaic acid, RU58841, rosemary, retinoic acid**, and vehicles/excipients including **alcohol, water, polyethylene glycol, and propylene glycol**.

**Concentration ranges in the specification:**
- Summary section: tofacitinib **0.1–10%**; bimatoprost **0.3–10%**; melatonin **0.1–2%**; azelaic acid **0.1–20%**; RU58841 **0.1–10%**.
- Detailed description: bimatoprost **0.1–10%**; tofacitinib **0.3–10%**. These differ from the summary's lower bounds; retain this discrepancy until the document owner resolves it.

The previously discussed **bimatoprost 1% + tofacitinib 3%** is a research concept within these broad ranges, **not confirmed to be the marketed Biohair formula**.

## Claimed mechanism and evidence boundaries
The specification **claims** that bimatoprost and tofacitinib synergistically induce or enhance hair growth and produce a faster onset than either alone. It provides **no comparative trial data, statistical results, study protocol, or clinical references** establishing this synergy. Website wording must call this a *proposed mechanism*, not a proven Biohair outcome.

External research context discussed in the project (not proof of Biohair efficacy):
- Bimatoprost **0.03%** is approved in the US for eyelash hypotrichosis; its scalp use and higher concentrations are separate research questions.
- Bimatoprost **1%** has been evaluated in early pharmacokinetic/tolerability studies for androgenetic alopecia (e.g., NCT02848300), not established as a clinically effective scalp regimen.
- Tofacitinib has been studied for immune-mediated alopecia areata; the evidence does not establish the efficacy or safety of a 3% topical bimatoprost/tofacitinib combination for general hair loss.
- **RU58841** is an experimental ingredient and is not an FDA-approved hair-loss treatment.

## Biohair history — documented timeline
1. **Technical concept, date unknown:** Invention-style specification describes topical bimatoprost plus tofacitinib with possible supplementary compounds and broad concentration ranges. Date, inventor, and legal patent status are not stated in the file.
2. **Research discussions, 2026:** Biohair-related research explored bimatoprost 1%, tofacitinib 3%, scalp regrowth literature, and investigational PP405. These discussions do not establish that PP405 is part of Biohair.
3. **Commercial status, confirmed by seller on 23 October 2026:** Biohair is already being sold; commercial formulation and regulatory details await documentation.
4. **Website development, 23 October 2026:** First draft of a Biohair website was created, drawing structural inspiration from Elite Hair Institute's non-surgical hair restoration website, with plans for research citations and evidence-aware claims.
5. **Knowledge base expansion, 23 October 2026:** This uploaded invention specification was reviewed and recorded as product-development source material.

## Website content policy
- Clearly distinguish **published studies on ingredients** from **clinical studies on Biohair itself**.
- Do not claim proven synergy, guaranteed regrowth, clinical efficacy, FDA approval, or a patented formula without supporting documentation.
- Because hair-regrowth claims can classify a marketed product as a drug under US law, obtain regulatory review before publishing sales claims or purchase flows.
- Avoid stating that the specification is an issued patent or that the marketed product includes any particular active ingredient until verified.

## Items needed to complete the record
- Biohair bottle/packaging and actual ingredient concentrations.
- Product launch date, origin story, company/manufacturer and brand ownership.
- Batch COAs, stability/quality records, labeling, and safety information.
- Any clinical or observational Biohair-specific evidence.
- Patent filing or publication identifiers, if applicable.
- Sales channel and intended US/overseas markets.

**Source:** user-supplied `Specs_TPP40336 (1).docx`, five pages, title *Methods and Compositions for Inducing and Enhancing Hair Growth*.
