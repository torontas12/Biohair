# CODEX HANDOFF — BioHair X® For Physicians + Research & Clinical Evidence

## Status and instructions
- **For Physicians desktop and mobile:** APPROVED working visual direction. Preserve existing wording, section order, ingredient preview/Read More details, physician profiles, FAQs and inquiry.
- **Research page:** APPROVED architecture, NOT approved final visual/copy. Build and present for review.
- **Do not publish without explicit sign-off.** Existing design assets and source documents are for implementation/reference.

## SOURCE OF TRUTH — IMPORTANT
1. `physicians/approved_physicians_full_content.html` is the actual long-form approved physician page. It includes the complete sections and Read More logic. Its physician portraits resolve through the adjacent `biohair_physician_assets/` folder. **Use this for approved text and interactions.**
2. `design/approved_desktop_hero_banner.png` is the approved premium blue hero composition. It contains text baked into the image. For accessibility and mobile, render the exact wording as HTML and use image art appropriately; do not duplicate text visibly.
3. `product/USER_SUPPLIED_BioHairX_bottle_carton.png` is the user's authentic supplied packaging reference. **Never redraw or replace the BioHair X bottle or carton with invented packaging.** Preserve the logo, colors, label and proportions. This is an image reference, not authorization to edit medicinal labeling.
4. `design/physicians_desktop_preview.png` and `design/physicians_mobile_preview.png` are visual references. The preview HTML `physicians/responsive_hero_experiment.html` is an experimental mobile hero and NOT the content source of truth.
5. `research/previous_site/clinical-research.html` and `science.html` contain additional previously assembled scientific references; use them as research inputs, not approved current design.

## For Physicians layout
1. Hero — For Physicians; A Pharmacological Approach to Hair Restoration; approved tagline, copy and Physician Inquiry CTA, original product artwork.
2. Developed for Physician-Directed Hair Restoration — three vertically arranged benefit cards and a compact white Latest Research panel to their right on desktop; stack on mobile.
3. One Formulation. Four Active Ingredients — compact navy/scientific header; two cards per row desktop and one per row mobile; Bimatoprost 1%, Tofacitinib 3%, Topical Finasteride 0.2%, Melatonin 0.5%; consistent coordinated scientific artwork; approximately three-sentence visible previews; accessible Read More / Read Less to expand the FULL approved text in place; discreet supporting study links.
4. Integrating BioHair X® Into Your Practice — three elegant horizontal icon columns desktop; stacked on mobile; retain exact approved descriptions.
5. Our Hair Restoration Specialists — original user-supplied photos and bios for Dr. Robert Hashemiyoon and Dr. Tom Flashman, without altering likeness.
6. Frequently Asked Questions — six functional accessible accordions.
7. Bring BioHair X® to Your Practice — form; connect to real approved backend or label as nonfunctional preview. Do not simulate successful submissions.

Use premium navy (#082c50), blue (#1765a0), icy blue (#f3f8fb), white, restrained scientific photography, serif headings, readable body type. Responsive widths 375, 390, 430, 768, 1280, 1440. No sticky research ticker. Preserve copy verbatim; propose any edits as diffs for approval.

## Research & Clinical Evidence page — build specification
- Hero: Research & Clinical Evidence. Subtitle: Exploring the pharmacological pathways and published research relevant to physician-directed hair restoration.
- Clinical Evidence at a Glance: study-type, route, concentration, indication, major limitations for each ingredient.
- Four ingredient research filters/cards: bimatoprost, tofacitinib/JAK, topical finasteride, melatonin.
- Featured 2026 bimatoprost 1% scalp PK/tolerability study. **Not a scalp regrowth efficacy trial.**
- Comprehensive clinical publications library: search/filter by ingredient, year, route, study type, and indication. Cards with verified full title, authors, journal, year, DOI/PMID, population, drug concentration, objective summary, limitations and original publication link.
- Explicit Evidence Gaps and Safety section. Physician research inquiry link.
- Cross-link the physician-page Latest Research panel and ingredient research references to the Research page.

### Initial bibliography to VERIFY and include (not exhaustive)
BIMATOPROST
1. Khidhir et al. 2013, FASEB J, human scalp follicles/preclinical: https://doi.org/10.1096/fj.12-218156
2. Subedi et al. 2022, delivery/preclinical: https://doi.org/10.1080/10717544.2022.2027046
3. Zeppieri et al. 2024, review: https://doi.org/10.3390/ph17050561
4. 2026 bimatoprost 1% scalp pharmacokinetics/tolerability: https://doi.org/10.1111/cts.70710

TOFACITINIB / JAK
5. Xing et al. 2014, Nature Medicine, preclinical: https://doi.org/10.1038/nm.3645
6. Harel et al. 2015, Science Advances, preclinical: https://doi.org/10.1126/sciadv.1500973
7. Kennedy Crispin et al. 2016, oral tofacitinib: https://doi.org/10.1172/jci.insight.89776
8. Bayart et al. 2017, pediatric topical JAK inhibitor cases: https://doi.org/10.1016/j.jaad.2017.03.024
9. 2022 retrospective oral tofacitinib + corticosteroids: https://doi.org/10.3389/fmed.2022.891434
10. Sardana et al. 2023 review: https://doi.org/10.4103/idoj.idoj_452_22
11. Chikhalkar et al. 2024 topical 2% tofacitinib: https://doi.org/10.4103/idoj.idoj_535_23 ; https://pmc.ncbi.nlm.nih.gov/articles/PMC11265738/

MELATONIN
12. 2024 Clinical Studies Using Topical Melatonin review: https://doi.org/10.3390/ijms25105167
13. Recover the original randomized placebo-controlled 40-woman topical melatonin trial citation from the review, verify and list separately.

FINASTERIDE
14. Extract and verify the 2021 Piraccini topical finasteride randomized trial from the bundled PDF; recover all other previously supplied finasteride studies, including DHT and systemic exposure findings.

ADDITIONAL PROVIDED SOURCES
- Review all bundled PDFs and `research/previous_site/` source content for further studies, including the earlier 90-patient retrospective and 13-patient cohorts, human follicle research, oral-vs-topical studies and other cited primary literature. Deduplicate and create a bibliography audit table of every study recovered, verified metadata, source file, evidence type and publication status.
- Bundled PDFs are original research reference materials; **do not imply each PDF is a trial of BioHair X itself.**
- The 2017 BioHair product document is background marketing/source material, not automatically a peer-reviewed publication.

## Scientific and regulatory guardrails
BioHair X® finished compounded formula has not been established as FDA-approved or clinically validated in controlled trials. LATISSE eyelash approval does not imply scalp bimatoprost approval. Oral tofacitinib/JAK studies do not prove efficacy of topical 3% tofacitinib; the 2026 1% bimatoprost study measured scalp exposure and tolerability, not regrowth. Avoid unsubstantiated clinical outcomes, superiority, synergy or safety claims. Flag existing claims and packaging directions for clinician/regulatory review; do not silently edit approved website copy.

## Deliverables
- Complete working desktop/mobile For Physicians page and Research page, integrated with shared navigation.
- Functional Read More, FAQs, research filters/search, external links, responsive images.
- Verified and deduplicated bibliography, with missing/unverified references clearly listed.
- Desktop/mobile screenshots for both pages, and change log.
- Review build only: obtain approval before deployment; connect inquiry only with authorized backend.
