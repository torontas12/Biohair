# For Physicians + Research & Clinical Evidence — review build

Nothing has been deployed. The homepage implementation was not changed by this build. The previous physician/research/science/homepage HTML files are preserved in `/workspace/Before-Physician-Research-Build.zip`.

## Open and run

- `physicians.html`: approved long-form physician content, responsive implementation.
- `clinical-research.html`: research architecture implemented for visual and editorial review.
- `bibliography-audit.html`: all selected records plus raw recovered reference candidates.
- No build, database, credentials or external font download is needed. Open the HTML files directly, or serve the website folder locally with `python3 -m http.server 8000`.
- Inquiry is deliberately disabled and explicitly labeled a nonfunctional preview. No submission success is simulated.

## Changes

1. Replaced the previous placeholder physician page with the package's actual approved full-content source. All approved headings, clinical/practice paragraphs, ingredient previews and expanded text, physician biographies and FAQs were preserved.
2. Replaced the product placeholder with a pixel-identical artwork-only crop of the approved blue hero. Text is rendered as selectable HTML once, without duplicated baked lettering. The authentic user-supplied bottle/carton PNG is also retained byte-for-byte under `assets/physicians/original-product.png`.
3. Preserved original portraits byte-for-byte. Matched the reference's horizontal portrait-led physician cards on desktop and stacked cards on mobile.
4. Added shared functioning navigation, a keyboard-accessible mobile menu, Read More/Read Less with `aria-controls` and hidden-state management, six native FAQ disclosures, explicit form labels and disabled preview fields.
5. Cross-linked Latest Research entries to specific research-library records, and ingredient sections to their corresponding research filters.
6. Built the research page with evidence-at-a-glance cards, four ingredient filters, featured bimatoprost research lead, publication search, year/route/study-type/indication filters, full-text-checked filter, pagination, empty state, limitations and safety sections, and research inquiry link.
7. Added JSON/CSV bibliography exports and an accessible audit page. No PDFs, labels, medication directions, portraits or product packaging were rewritten or generated.

## Source verification boundaries

23 selected records are represented. Five publications were checked against bundled full-text PDFs: Piraccini, Chikhalkar, Sardana, Jin and Purohit. Remaining records are explicitly marked as secondary citations, handoff-only leads or unrecovered original citations. No unknown author lists, DOIs, concentrations, sample sizes or efficacy results were filled in by inference.

The 160 deduplicated raw numbered-reference candidates were recovered from all five research PDF bibliographies. Each retains its source occurrence and pending verification status. Conservative text deduplication is not a final identity-based bibliography audit; some source variants may still represent the same publication. Not all candidates are hair-growth studies: the source bibliographies include methodological tools, regulatory labels, background biology and other indications. They are not presented as 160 verified hair-restoration trials.

The BioHair 7X document is background marketing material and was excluded from peer-reviewed evidence. It contains older minoxidil and melatonin claims without complete primary citations. Previous-site clinical/science HTML contains no identifiable publication citations; its placeholder text was not treated as evidence. The knowledge-base/history document was reviewed as background, not a study.

## Important research findings and unresolved items

- Piraccini DOI 10.1111/jdv.17738: online publication 2021, journal issue 2022, 36:286–294. The studied 0.25% w/w spray differs from BioHair X 0.2%. Reported lower systemic exposure is not zero systemic exposure.
- Purohit DOI 10.1002/jcph.1360: journal issue 2019, 59:811–820 (2018 online/copyright context). Atopic dermatitis PK/modeling, not scalp regrowth or direct pediatric efficacy evidence.
- Jin 2026 DOI 10.1111/cts.70544: 61-patient oral tofacitinib cohort, not the requested bimatoprost study.
- Featured bimatoprost DOI 10.1111/cts.70710: full metadata/methods not verified. It is labeled as an unverified scalp PK/tolerability lead, never a regrowth efficacy trial.
- The requested 90-patient citation was recovered as Liu et al., JAAD 2017;76:22–28. Primary text is still missing. The 13-patient cohort was recovered from the Sardana review clinical discussion and reference 24 as Dincer Rota et al., Journal of Cosmetic Dermatology 2021;20:3026–3033. Primary-source verification remains outstanding.
- The original 40-woman melatonin citation still needs recovery from the linked review. Neither that review nor the primary trial PDF was bundled. Its patient count/concentration/duration are attributed to supplied source material and labeled unverified.
- Online publication verification attempts returned proxy-policy 403 denials for Crossref and PMC. External publication links have valid URL syntax but successful live access is not claimed. Full bibliographic verification remains outstanding.

## Network requirement saved

A cloud environment configuration draft preserves existing package-manager presets and adds custom research destinations: api.crossref.org, doi.org, pubmed.ncbi.nlm.nih.gov, pmc.ncbi.nlm.nih.gov, eutils.ncbi.nlm.nih.gov, www.mdpi.com and onlinelibrary.wiley.com. Draft persistence was confirmed, but saving does not apply runtime policy. Review/save the environment settings changes and publish the environment configuration to enable verification. This is cloud environment configuration, not website deployment. No secret or credential is required for these public sources.

## Visual comparison

The physician page was compared directly with both approved previews: premium blue hero, left editorial cards/right white research panel, two-column desktop and single-column mobile ingredients, three-column desktop practice section, original portrait-led specialist cards, FAQ and inquiry sequence. Heading line breaks and portrait layout were refined after initial browser inspection. The provided desktop PNG includes a large blank area below its actual page; it is not reproduced as website content. Mobile navigation was made collapsible to avoid the reference's cramped header.

Remaining visual differences include the reconstructed HTML hero text/system font metrics, a slight seam between the pale copy panel and isolated hero art, responsive spacing, larger accessible controls and explicit form labels. These preserve source wording and artwork but are not a claim of pixel identity. The research page has approved architecture only; its new visual/copy treatment awaits review.

## Required clinician/content review

See `CLAIM_AND_LABEL_REVIEW.md`. The original label PDF and carton disagree on ingredient count. Approved physician wording is retained despite documented claims requiring substantiation. No proposed text edits were silently applied.

## Validation evidence

Full-page Chromium screenshots:
- physicians-390.png: 390 × 9716
- physicians-1440.png: 1440 × 5436
- clinical-research-390.png: 390 × 12396
- clinical-research-1440.png: 1440 × 6569

Both pages passed at 375, 390, 430, 768, 1280 and 1440px: no measured horizontal overflow, heading/card text spill, broken images or local resource/page errors. All four ingredient expansions/collapses, all six FAQs, mobile menu/Escape, disabled inquiry fields, ingredient search/filter, author search, empty state, verified-only filter, combined year/route, study-type and indication filters, pagination across all 23 records and physician-to-research deep links passed. Local links and anchors returned HTTP 200 and resolved targets. External links are not asserted as live-verified.

Approved physician source-text comparisons and byte/pixel identity of portraits, authentic product asset and approved hero-art crop are recorded in `source-preservation-checks.json`. Browser test results are in `browser-checks.json` and `link-and-filter-checks.json`.
