# Source discrepancies and claims retained for review

No approved physician wording or product labeling was silently corrected. These are review findings, not new marketing claims.

## Conflicting packaging sources

`product/label_source.pdf` lists tofacitinib 3%, melatonin 0.5% and bimatoprost 1%, and repeatedly describes **three** active ingredients. It does not list finasteride. The authentic supplied bottle/carton image and approved physician content list **four**, adding finasteride 0.2%. The PDF also includes azelaic acid among inactive ingredients. The older BioHair 7X marketing document discusses minoxidil and is not proof of the current four-ingredient composition.

Please confirm which label revision and actual dispensed formulation are current. All supplied product/label artwork remains unedited. The prescription directions and warnings must be reviewed by the responsible clinician/pharmacy against the current formulation; appearance approval does not establish dosing correctness.

## Approved claims requiring substantiation

- Clinical card: “improving long-term results and patient satisfaction.” The source already flags this claim; that flag remains visible.
- Bimatoprost expanded copy: “confirmed scalp tissue penetration and favorable short-term tolerability.” This remains approved text, but the referenced 2026 paper has not yet been independently verified. The research page explicitly labels the citation pending and distinguishes PK/tolerability from efficacy.
- Physician credentials, the co-founder statement, Dr. Flashman's five-year use statement, profile identity and photograph permissions need owner confirmation. The supplied note requesting verification is retained.
- Source label claims include “scientifically proven,” “unmatched,” and reversal of hair loss “in as little as 4 months.” These were not promoted into the new research copy. Packaging artwork was preserved rather than edited; source authenticity is not verification of each claim.

## Proposed action, awaiting approval

Confirm current packaging/formulation and substantiate or separately approve revisions to the above claims. No exact wording changes are proposed as already approved; this review build retains the source text and does not go live.
