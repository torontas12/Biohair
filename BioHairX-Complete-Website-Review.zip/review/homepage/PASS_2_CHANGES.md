# Homepage refinement pass 2

The complete prior implementation was preserved before edits in `/workspace/Homepage Version 1.zip`.

## Exactly what changed

- Ingredient descriptions increased from 11px to 12px on mobile, with 1.4 line height, 10px body padding and clearer headline spacing. The two-column mobile arrangement is unchanged.
- How It Works descriptions now use 1.5 line height; patient-benefit descriptions increased from 12px to 13px with 1.5 line height. Hero buttons remain at least 47px tall including borders. The tagline scales to 22px only on 360–389px phones to prevent text spill.
- Three science images were extracted directly from the approved mobile PNG into individual PNG files. Real `<img>` elements with distinct alt text and equal tile boxes replace background crops. Each tile contains only its own approved illustration, with proportional fitting and no generated artwork.
- Four desktop ingredient header illustrations were isolated from the approved desktop PNG, eliminating neighboring-card bleed at intermediate widths. At 1024px, ingredient cards use two columns to accommodate full text; at 1440px, they retain four columns.
- Desktop ingredient descriptions use 13px/1.4 text. Results/Ingredients padding is aligned at 24px, process steps share a consistent grid, and subtle borders align the benefits/patient/science row and testimonial/FAQ row.
- At 900–1199px only, the hero background is bounded to its illustration region so the screenshot's lower website sections cannot bleed into the hero. The 390px and 1440px hero/header/trust rendering is unchanged from Version 1.
- Superseded science background selectors and unused ingredient-image selectors were removed. The CSS was expanded into readable declaration blocks. JavaScript is unchanged.

## Validation

Chromium full-page screenshots: `review/mobile-390.png` (390 × 4791) and `review/desktop-1440.png` (1440 × 2135). Additional QC screenshots cover 375, 768 and 1024px. Layout checks cover all requested sizes: 375, 390, 768, 1024 and 1440px. No measured horizontal overflow or text clipping; science tiles load at equal dimensions. Navigation, Escape dismissal, FAQ disclosure, hero anchor and all 11 unique local page destinations passed. Target screenshots have no broken HTML images or browser page/resource errors.

Visible page copy was programmatically compared with Version 1 and is unchanged, including all ingredient concentrations and descriptions. All supporting HTML pages and homepage JavaScript are byte-identical to Version 1. The header, hero and trust band were also compared pixel-for-pixel at both target screenshot sizes before the final tablet-only correction.

## Direct reference comparison and remaining limits

The approved navy, white, pale-blue and green palette, mobile reading order, and hero direction are preserved. Larger ingredient text intentionally increases mobile page height by 136px versus Version 1. The full approved descriptions make desktop ingredient cards taller than the shorter descriptions visible in the desktop reference; no text was shortened to force a match. The process row is aligned while keeping the same three steps. The science imagery now matches the three distinct approved illustrations without adjacent screenshot elements.

The extracted science originals are only 71–73 × 117 pixels; their sharpness is limited. Standalone high-resolution science illustrations are still needed. The original vector/transparent logo, verified high-resolution bottle photograph, label artwork and carton artwork remain missing. Existing approved reference composites were retained, not regenerated. Their product rendering and raster softness remain as in Version 1; independent product-file accuracy cannot be established from flattened composites. The references themselves show somewhat different mobile and desktop packaging views, so identical standalone packaging artwork still requires the original assets.

Other retained differences include system-font metrics, pre-existing raster logo/patient/product crops, line-icon details and minor reference spacing. Testimonial and results imagery remain visibly marked as unverified placeholders. No new claims, testimonials, pages, checkout or deployment were added. Physicians and Research pages were not modified.
